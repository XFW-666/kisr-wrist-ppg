# Sensor suite (node) ↔ dataset channels

| Node sensor | Dataset channel | Used in |
|---|---|---|
| Green PPG (AFE4400) | wrist_ppg | All experiments |
| Wide-range accel | wrist_low/wide_range_accelerometer | IMU subspace (default acc) |
| Low-noise accel | wrist_low_noise_accelerometer | Sensor ablation |
| Gyroscope | wrist_gyro_{x,y,z} | IMU subspace |
| Magnetometer | wrist_mag_{x,y,z} | Sensor ablation |
| Chest ECG header | chest_ecg | HR reference |
| Temp / ALS / baro | (not in dataset) | Node-only context sensing |
