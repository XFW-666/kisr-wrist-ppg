"""Fig. 5 - Subspace projection and reconstruction, shown on a real window.

Panels are computed from an actual difficult window of the wrist dataset:
(a) PPG spectrogram,
(b) kinematic mask (bins attributed to the motion subspace by the IMU),
(c) PPG-motion coherence,
(d) applied per-bin gain, including the protected cardiac bins,
(e) cleaned spectrogram,
(f) time-domain PPG before/after reconstruction.
Nothing here is synthetic: every panel comes from kisr(..., return_diag=True).
"""
import os
import sys
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import figstyle as FS
import ppglib as pl
import kisr as K
import matplotlib.pyplot as plt

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FIGS = os.path.join(ROOT, "figures")
WRIST = os.path.join(ROOT, "data", "wrist")

REC = "s1_high_resistance_bike"
WIN_S = 8.0


def main():
    rec = pl.load_wrist(os.path.join(WRIST, REC))
    fs = rec["fs"]
    ppg = rec["ppg"]
    imu = np.concatenate([rec["acc"], rec["gyro"]], axis=1)
    wl = int(WIN_S * fs)

    # pick the window with the largest accelerometer variance: hardest motion
    n_win = max(1, (len(ppg) - wl) // wl)
    best, best_v = 0, -1.0
    for i in range(n_win):
        s = i * wl
        v = float(np.var(pl.accel_magnitude(imu[s:s + wl, :3])))
        if v > best_v:
            best_v, best = v, s
    p = ppg[best:best + wl]
    i_ = imu[best:best + wl]

    nperseg, hop = 256, 64
    cleaned, diag = K.kisr(p, i_, fs, nperseg=nperseg, hop=hop, return_diag=True)
    freqs = diag["freqs"]
    mask = diag["mask"]
    coh = diag["coh"]
    gain = diag["gain"]
    Pb = diag["pow_before"]
    Pa = diag["pow_after"]

    band = (freqs >= 0.4) & (freqs <= 5.0)
    fb = freqs[band]
    t = np.arange(p.size) / fs

    fig = plt.figure(figsize=(7.0, 4.7))
    gs = fig.add_gridspec(3, 2, hspace=0.38, wspace=0.28,
                          height_ratios=[1, 1, 0.85])

    def spec(ax, P, title):
        Pdb = 10 * np.log10(P[:, band].T + 1e-12)
        vmax = np.percentile(Pdb, 99)
        im = ax.pcolormesh(np.arange(P.shape[0]) * hop / fs, fb, Pdb,
                           cmap="magma", vmin=vmax - 40, vmax=vmax, shading="auto")
        ax.set_ylim(0.4, 5.0)
        ax.set_ylabel("Frequency (Hz)")
        ax.set_title(title, fontsize=7.5)
        return im

    ax = fig.add_subplot(gs[0, 0])
    spec(ax, Pb, "(a) PPG spectrogram (before)")
    ax.text(0.02, 0.96, "(a)", transform=ax.transAxes, fontsize=8.5, fontweight="bold", va="top", bbox=dict(fc="white", ec="none", alpha=0.75, pad=0.6))

    ax = fig.add_subplot(gs[0, 1])
    ax.pcolormesh(np.arange(mask.shape[0]) * hop / fs, freqs,
                  mask.astype(float).T, cmap="Blues", vmin=0, vmax=1, shading="auto")
    ax.set_ylim(0.4, 5.0)
    ax.set_ylabel("Frequency (Hz)")
    ax.set_title("(b) Kinematic motion subspace (IMU)", fontsize=7.5)
    ax.text(0.02, 0.96, "(b)", transform=ax.transAxes, fontsize=8.5, fontweight="bold", va="top", bbox=dict(fc="white", ec="none", alpha=0.75, pad=0.6))

    ax = fig.add_subplot(gs[1, 0])
    C2 = coh
    im = ax.pcolormesh(np.arange(C2.shape[0]) * hop / fs, freqs, C2.T,
                       cmap="viridis", vmin=0, vmax=1, shading="auto")
    ax.set_ylim(0.4, 5.0)
    ax.set_ylabel("Frequency (Hz)")
    ax.set_title("(c) PPG-motion coherence", fontsize=7.5)
    cb = fig.colorbar(im, ax=ax, fraction=0.045, pad=0.02)
    cb.ax.tick_params(labelsize=6)
    ax.text(0.02, 0.96, "(c)", transform=ax.transAxes, fontsize=8.5, fontweight="bold", va="top", bbox=dict(fc="white", ec="none", alpha=0.75, pad=0.6))

    ax = fig.add_subplot(gs[1, 1])
    im = ax.pcolormesh(np.arange(gain.shape[0]) * hop / fs, freqs, gain.T,
                       cmap="turbo", vmin=0, vmax=1, shading="auto")
    ax.set_ylim(0.4, 5.0)
    ax.set_ylabel("Frequency (Hz)")
    ax.set_title("(d) Applied gain (cardiac bins protected)", fontsize=7.5)
    cb = fig.colorbar(im, ax=ax, fraction=0.045, pad=0.02)
    cb.ax.tick_params(labelsize=6)
    ax.text(0.02, 0.96, "(d)", transform=ax.transAxes, fontsize=8.5, fontweight="bold", va="top", bbox=dict(fc="white", ec="none", alpha=0.75, pad=0.6))

    ax = fig.add_subplot(gs[2, 0])
    spec(ax, Pa, "(e) Reconstructed spectrogram")
    ax.set_xlabel("Time (s)")
    ax.text(0.02, 0.96, "(e)", transform=ax.transAxes, fontsize=8.5, fontweight="bold", va="top", bbox=dict(fc="white", ec="none", alpha=0.75, pad=0.6))

    ax = fig.add_subplot(gs[2, 1])
    ax.plot(t, p - p.mean(), color=FS.C["black"], lw=0.6, label="Raw PPG")
    ax.plot(t, cleaned - cleaned.mean() - 2.2 * np.std(p), color=FS.C["red"],
            lw=0.6, label="KISR output")
    ax.set_xlabel("Time (s)")
    ax.set_yticks([])
    ax.legend(frameon=True, framealpha=0.9, edgecolor="gray", fontsize=6, loc="lower right")
    ax.set_title(f"Time domain ({REC})", fontsize=7.5)
    ax.text(0.02, 0.96, "(f)", transform=ax.transAxes, fontsize=8.5, fontweight="bold", va="top", bbox=dict(fc="white", ec="none", alpha=0.75, pad=0.6))

    out = os.path.join(FIGS, "fig5_subspace_projection.png")
    fig.savefig(out, bbox_inches="tight", dpi=950)
    print("saved", out)


if __name__ == "__main__":
    main()
