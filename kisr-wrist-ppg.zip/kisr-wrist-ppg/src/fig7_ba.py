"""Fig. 7 - Bland-Altman agreement plots per method (multi-panel).

Each panel: mean of (estimate, reference) vs difference, with limits of agreement
(mean +/- 1.96 SD) computed from the real pooled windows.
"""
import os
import sys
import json
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import figstyle as FS
import matplotlib.pyplot as plt

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FIGS = os.path.join(ROOT, "figures")
OUT = os.path.join(ROOT, "out")

METHODS = ["Raw (bandpass)", "LMS adaptive", "Spectral subtraction",
           "Wavelet+IMU", "ICA+IMU", "KISR (proposed)"]
SHORT = ["Raw", "LMS", "SpecSub", "Wavelet", "ICA", "KISR"]


def main():
    os.makedirs(FIGS, exist_ok=True)
    with open(os.path.join(OUT, "results_windows.json")) as f:
        results = json.load(f)

    fig, axes = plt.subplots(2, 3, figsize=(7.0, 2.9), sharex=True, sharey=True)
    fig.subplots_adjust(hspace=0.22, wspace=0.25)

    stats = {}
    for ax, m, sh in zip(axes.ravel(), METHODS, SHORT):
        est = np.array([w[m] for w in results if w.get(m) is not None])
        ref = np.array([w["ref"] for w in results if w.get(m) is not None])
        mean = (est + ref) / 2.0
        diff = est - ref
        md, sd = diff.mean(), diff.std()
        lo, hi = md - 1.96 * sd, md + 1.96 * sd
        stats[m] = {"mean_diff": float(md), "loa_lo": float(lo), "loa_hi": float(hi)}
        ax.scatter(mean, diff, s=4, alpha=0.45, color=FS.METHOD_COLORS[m],
                   edgecolors="none")
        ax.axhline(md, color=FS.C["black"], lw=0.8)
        ax.axhline(lo, color=FS.C["red"], lw=0.7, ls="--")
        ax.axhline(hi, color=FS.C["red"], lw=0.7, ls="--")
        ax.set_title(f"{sh}  (bias {md:+.1f}, LoA [{lo:.0f}, {hi:.0f}])", fontsize=7)
        ax.set_ylim(-80, 80)
        ax.set_yticks([-60, 0, 60])
        ax.set_xlim(30, 190)
        ax.set_xticks([50, 100, 150])
    # single shared xlabel centered under the bottom row (one only, not three)
    fig.supxlabel("Mean of estimate and reference (bpm)", fontsize=7)
    for ax in axes[1]:
        ax.set_xlabel("")
    for ax in axes[:, 0]:
        ax.set_ylabel("Difference (bpm)")

    out = os.path.join(FIGS, "fig7_bland_altman.png")
    fig.savefig(out, bbox_inches="tight")
    with open(os.path.join(OUT, "fig7_stats.json"), "w") as fj:
        json.dump(stats, fj, indent=1)
    print("saved", out)


if __name__ == "__main__":
    main()
