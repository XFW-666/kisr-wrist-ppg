"""Fig. 2 - Real signal characterisation across activities (multi-panel).

Panel (a): chest ECG reference; (b) wrist PPG; (c) 3-axis accelerometer;
(d) PPG spectrum at three motion intensities. All traces are real PhysioNet
'wrist' recordings; no synthetic data.
"""
import os
import sys
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import figstyle as FS
import ppglib as pl
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WRIST = os.path.join(ROOT, "data", "wrist")
FIGS = os.path.join(ROOT, "figures")

RECS = {"bike": "s1_high_resistance_bike", "walk": "s1_walk",
        "run": None}  # filled when a run record is complete


def complete_records():
    sys.path.insert(0, os.path.join(ROOT, "src"))
    from fetch import expected_dat_size
    out = []
    for f in sorted(os.listdir(WRIST)):
        if f.endswith(".dat"):
            hea = os.path.join(WRIST, f[:-4] + ".hea")
            if os.path.exists(hea):
                exp = expected_dat_size(hea)
                if exp is not None and os.path.getsize(os.path.join(WRIST, f)) == exp:
                    out.append(f[:-4])
    return out


def main():
    os.makedirs(FIGS, exist_ok=True)
    recs = complete_records()
    recs.sort(key=lambda r: (0 if "run" in r else 1 if "walk" in r else 2, r))
    chosen = {}
    for act in ("bike", "walk", "run"):
        for r in recs:
            if act in r and act not in chosen:
                chosen[act] = r
    print("using records:", chosen)

    show_s = 12.0
    fig = plt.figure(figsize=(7.0, 4.0))
    gs = fig.add_gridspec(4, 3, hspace=0.48, wspace=0.30,
                          height_ratios=[1, 1, 1, 1.1])

    spectra = {}
    for col, (act, rec) in enumerate(chosen.items()):
        r = pl.load_wrist(os.path.join(WRIST, rec))
        fs = r["fs"]
        n = int(show_s * fs)
        t = np.arange(n) / fs
        ecg = r["ecg"][:n]
        ppg = pl.bandpass(r["ppg"][:n], fs, 0.5, 8.0)
        acc = pl.accel_magnitude(r["acc"][:n]) - np.mean(pl.accel_magnitude(r["acc"][:n]))

        ax = fig.add_subplot(gs[0, col])
        ax.plot(t, ecg, color=FS.C["black"], lw=0.7)
        ax.set_title(f"{FS.ACT_LABEL[act]}\n({rec.replace('_', ' ')})", fontsize=7.5)
        ax.set_ylabel("ECG (mV)" if col == 0 else "")
        ax.yaxis.set_major_locator(MaxNLocator(4, prune="both"))
        ax.set_xlim(0, show_s)
        ax.tick_params(labelbottom=False)
        if col == 0:
            ax.text(-0.52, 0.5, "(a)", transform=ax.transAxes, fontsize=9,
                    fontweight="bold", ha="center", va="center", clip_on=False)

        ax = fig.add_subplot(gs[1, col])
        ax.plot(t, ppg, color=FS.C["red"], lw=0.7)
        ax.set_ylabel("PPG (a.u.)" if col == 0 else "")
        ax.yaxis.set_major_locator(MaxNLocator(4, prune="both"))
        ax.set_xlim(0, show_s)
        ax.tick_params(labelbottom=False)
        if col == 0:
            ax.text(-0.52, 0.5, "(b)", transform=ax.transAxes, fontsize=9,
                    fontweight="bold", ha="center", va="center", clip_on=False)

        ax = fig.add_subplot(gs[2, col])
        ax.plot(t, acc, color=FS.C["blue"], lw=0.7)
        ax.set_ylabel(r"$|a|$ (m/s$^2$)" if col == 0 else "")
        ax.yaxis.set_major_locator(MaxNLocator(4, prune="both"))
        ax.set_xlabel("Time (s)" if col == 2 else "")
        ax.set_xlim(0, show_s)
        if col == 0:
            ax.text(-0.52, 0.5, "(c)", transform=ax.transAxes, fontsize=9,
                    fontweight="bold", ha="center", va="center", clip_on=False)

        f, P = pl.welch(ppg, fs, nperseg_s=8.0)
        spectra[act] = (f, P)

    ax = fig.add_subplot(gs[3, :])
    for act, (f, P) in spectra.items():
        band = (f >= 0.4) & (f <= 5.0)
        Pn = P[band] / P[band].max()
        ax.plot(f[band], Pn, color=FS.ACT_COLORS[act], label=FS.ACT_LABEL[act])
    ax.set_xlabel("Frequency (Hz)")
    ax.set_ylabel("Normalized PPG PSD")
    ax.set_xlim(0.4, 5.0)
    ax.legend(frameon=False, ncol=3, loc="upper right")
    ax.text(-0.14, 0.5, "(d)", transform=ax.transAxes, fontsize=9,
            fontweight="bold", ha="right", va="center", clip_on=False)

    out = os.path.join(FIGS, "fig2_signal_characterisation.png")
    fig.savefig(out, bbox_inches="tight")
    print("saved", out)


if __name__ == "__main__":
    main()
