"""Fig. 8 - Per-record breakdown: heatmap of MAE + per-record forest-style plot.

(a) Heatmap of per-record MAE (rows = records, cols = methods).
(b) Per-record MAE grouped by activity, with number of windows annotated.
Everything comes from out/results_windows.json (real pooled windows).
"""
import os
import sys
import json
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import figstyle as FS
import matplotlib.pyplot as plt

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FIGS = os.path.join(ROOT, "figures")
OUT = os.path.join(ROOT, "out")

METHODS = ["Raw (bandpass)", "LMS adaptive", "Spectral subtraction",
           "Wavelet+IMU", "ICA+IMU", "KISR (proposed)"]
SHORT = ["Raw", "LMS", "SpecSub", "Wav", "ICA", "KISR"]


def main():
    with open(os.path.join(OUT, "results_windows.json")) as f:
        results = json.load(f)

    recs = sorted({w["rec"] for w in results})
    act_of = {w["rec"]: w["act"] for w in results}

    M = np.full((len(recs), len(METHODS)), np.nan)
    n_win = np.zeros(len(recs), int)
    for i, r in enumerate(recs):
        sub = [w for w in results if w["rec"] == r]
        n_win[i] = len(sub)
        for j, m in enumerate(METHODS):
            e = [abs(w[m] - w["ref"]) for w in sub if w.get(m) is not None]
            if e:
                M[i, j] = float(np.mean(e))

    fig = plt.figure(figsize=(7.0, 2.37))
    gs = fig.add_gridspec(1, 2, width_ratios=[1.0, 1.25], wspace=0.32)

    # ---- (a) heatmap
    ax = fig.add_subplot(gs[0, 0])
    im = ax.imshow(M, aspect="auto", cmap="RdYlGn_r", vmin=0, vmax=60)
    ax.set_xticks(range(len(METHODS)))
    ax.set_xticklabels(SHORT, rotation=20, ha="right", fontsize=5.4)
    ylab = [f"{r}  (n={n})" for r, n in zip(recs, n_win)]
    ax.set_yticks(range(len(recs)))
    ax.set_yticklabels(ylab, fontsize=5.8)
    for i in range(len(recs)):
        for j in range(len(METHODS)):
            if np.isfinite(M[i, j]):
                ax.text(j, i, f"{M[i,j]:.0f}", ha="center", va="center",
                        fontsize=5.4, color="black")
    cb = fig.colorbar(im, ax=ax, fraction=0.04, pad=0.08)
    cb.ax.set_xlabel("MAE (bpm)", fontsize=5.6)
    cb.ax.tick_params(labelsize=6)
    ax.set_title("Per-record MAE", fontsize=8)
    ax.text(-0.42, 1.05, "(a)", transform=ax.transAxes, fontsize=9, fontweight="bold")

    # ---- (b) per-record slope/forest plot
    ax = fig.add_subplot(gs[0, 1])
    y = np.arange(len(recs))
    for j, m in enumerate(METHODS):
        ax.plot(M[:, j], y + (j - 2.5) * 0.12, "o", ms=3.2,
                color=FS.METHOD_COLORS[m], label=SHORT[j], alpha=0.9)
    ax.set_yticks(y)
    ax.set_yticklabels([])
    ax.tick_params(axis="y", length=0)
    ax.invert_yaxis()
    ax.set_xlabel("MAE (bpm)")
    ax.axvline(5, color="gray", ls="--", lw=0.8)
    ax.text(5.4, len(recs) - 0.4, "5 bpm", fontsize=5.6, color="gray")
    ax.legend(frameon=True, framealpha=0.9, fontsize=5.6, ncol=3, loc="upper center", bbox_to_anchor=(0.5, -0.34))
    for i, r in enumerate(recs):
        ax.text(1.002, i, FS.ACT_LABEL[act_of[r]], transform=ax.get_yaxis_transform(),
                ha="left", va="center", fontsize=5.2, color=FS.ACT_COLORS[act_of[r]])
    ax.text(-0.30, 1.05, "(b)", transform=ax.transAxes, fontsize=9, fontweight="bold")

    out = os.path.join(FIGS, "fig8_per_record.png")
    fig.savefig(out, bbox_inches="tight", dpi=950)
    print("saved", out)


if __name__ == "__main__":
    main()
