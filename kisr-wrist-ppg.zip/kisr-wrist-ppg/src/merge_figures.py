"""Merge the 16 figures into 9 composite figures (PIL stacking).

Plan (paper order after merge):
  g1 = fig1 system overview  + fig4 KISR blocks      (III, methods)
  g2 = fig5 subspace process                          (III, 6 panels, keep)
  g3 = fig2 signal chars      + fig3 mechanism        (V, 8 panels total)
  g4 = fig15 sensor waveforms                         (V, 6 rows, keep)
  g5 = fig6 main results      + fig7 Bland-Altman     (V, 3+6 panels)
  g6 = fig8 per-record        + fig9 ablation        (V/VI, 2+3 panels)
  g7 = fig10 design space     + fig12 power           (VI, 3+3 panels)
  g8 = fig11 hardware         + fig13 node anatomy
       + fig14 optics                                  (VII, 3+2+2 panels)
  g9 = fig11b KiCad schematic                         (VII, full sheet)
"""
import os
from PIL import Image

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FIGS = os.path.join(ROOT, "figures")

MERGES = [
    ("g1_methods", ["fix/fig_overview_v2.png", "fix/fig_pipeline_v2.png"]),
    ("g2_subspace", ["fig5_subspace_projection.png"]),
    ("g3_signal_mechanism", ["fig2_signal_characterisation.png",
                             "fix/fig_freq_v2.png"]),
    ("g4_waveforms", ["fig15_sensor_waveforms.png", "fix/fig_optical_fixed.png"]),
    ("g5_main_ba", ["fig6_main_results.png", "fig7_bland_altman.png"]),
    ("g6_record_ablation", ["fig8_per_record.png", "fig9_ablation.png"]),
    ("g7_design_power", ["fig10_design_space.png", "fig12_power.png"]),
    ("g8_hardware", ["fix/fig_hardware_fixed.png", "fix/fig_node_fixed.png"]),
    ("g9_kicad", ["fig11b_kicad_schematic.png"]),
]

GAP = 10  # white separator px


def load(name):
    return Image.open(os.path.join(FIGS, name)).convert("RGB")


def stack(names, out_name, target_w=5670):
    imgs = []
    for n in names:
        im = load(n)
        if im.width > target_w:
            h = round(im.height * target_w / im.width)
            im = im.resize((target_w, h), Image.LANCZOS)
        elif im.width < target_w:
            # never upscale (blurry text): pad with white to the target width
            h = im.height
            canvas = Image.new("RGB", (target_w, h), "white")
            canvas.paste(im, ((target_w - im.width) // 2, 0))
            im = canvas
        imgs.append(im)
    total_h = sum(im.height for im in imgs) + GAP * (len(imgs) - 1)
    canvas = Image.new("RGB", (target_w, total_h), "white")
    y = 0
    for i, im in enumerate(imgs):
        canvas.paste(im, (0, y))
        y += im.height
        if i < len(imgs) - 1:
            # thin gray separator line
            for dx in range(0, target_w, 8):
                canvas.putpixel((dx, y + GAP // 2), (210, 210, 210))
            y += GAP
    out = os.path.join(FIGS, out_name + ".png")
    canvas.save(out, optimize=True)
    print("merged", out, canvas.size)
    return out


if __name__ == "__main__":
    for out_name, names in MERGES:
        stack(names, out_name)
    print("done: %d composite figures" % len(MERGES))
