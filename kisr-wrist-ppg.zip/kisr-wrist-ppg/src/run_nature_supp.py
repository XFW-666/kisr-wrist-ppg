"""Nature-grade supplements computed on the real 15-record cohort:

(1) Sensor-channel ablation: KISR driven by different IMU subsets
    (wide-range accel, low-noise accel, gyro, magnetometer, and unions).
(2) Inference statistics: subject-level paired comparisons of KISR vs each
    baseline (Wilcoxon signed-rank), window-level paired tests, bootstrap 95%
    CIs for MAE, and Cohen's dz effect sizes.
(3) Failure-mechanism analysis: per-window spectral overlap between the
    cardiac band and the kinematic harmonic comb ("interference index") and
    its association with HR error, an empirical "when does it fail" law.

Writes out/sensor_ablation.json, out/stats.json, out/mechanism.json.
"""
import json
import os
import sys
import numpy as np
from scipy import stats as sps

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import ppglib as pl
import kisr as K
from run_experiment import complete_records, activity_of, intensity_of, WIN_S, STEP_S, WRIST, OUT


# ---------------------------------------------------------------------------
# (1) sensor-channel ablation
# ---------------------------------------------------------------------------
def kisr_with(imu_cols):
    def f(p, i, fs):
        return K.kisr(p, i, fs), fs
    return f


def sensor_variants(rec):
    """Return dict name -> (n_samples, n_channels) imu array for one record."""
    acc = rec["acc"]            # wide-range accelerometer (as used everywhere)
    acc_ln = rec.get("acc_ln")  # low-noise accelerometer
    gyro = rec["gyro"]
    mag = rec.get("mag")
    out = {
        "acc (wide-range)": acc,
        "acc (low-noise)": acc_ln if acc_ln is not None else acc,
        "gyro": gyro,
        "acc + gyro (baseline)": np.concatenate([acc, gyro], axis=1),
        "acc + gyro + mag": np.concatenate([acc, gyro, mag], axis=1),
        "acc + acc_ln + gyro + mag": np.concatenate(
            [acc, acc_ln if acc_ln is not None else acc, gyro, mag], axis=1),
    }
    return out


def run_sensor_ablation():
    recs = complete_records()
    accs = {}
    for rec_name in recs:
        rec = pl.load_wrist(os.path.join(WRIST, rec_name))
        fs = rec["fs"]
        ppg = rec["ppg"]
        rp = pl.ecg_rpeaks(rec["ecg"], fs)
        wl, sl = int(WIN_S * fs), int(STEP_S * fs)
        variants = sensor_variants(rec)
        for name, imu_full in variants.items():
            accs.setdefault(name, [])
        for s in range(0, len(ppg) - wl, sl):
            e = s + wl
            ref = pl.ref_hr(rp, fs, s / fs, e / fs)
            if not np.isfinite(ref) or ref < 40 or ref > 180:
                continue
            p = ppg[s:e]
            for name, imu_full in variants.items():
                i = imu_full[s:e]
                try:
                    y = K.kisr(p, i, fs)
                    hr, _ = pl.hr_harmonic(y, fs, prev=None)
                    if np.isfinite(hr):
                        accs[name].append(abs(float(hr) - ref))
                except Exception:
                    pass
        print(f"  sensors {rec_name} done", flush=True)
    out = {}
    for name, errs in accs.items():
        e = np.asarray(errs, float)
        out[name] = {"mae": float(e.mean()) if e.size else None, "n": int(e.size)}
        print(f"  {name:30s} MAE={out[name]['mae']} n={e.size}", flush=True)
    return out


# ---------------------------------------------------------------------------
# (2) statistics
# ---------------------------------------------------------------------------
def bootstrap_ci(errs, n_boot=4000, seed=0):
    rng = np.random.default_rng(seed)
    errs = np.asarray(errs, float)
    if errs.size == 0:
        return [None, None]
    idx = rng.integers(0, errs.size, size=(n_boot, errs.size))
    means = errs[idx].mean(axis=1)
    return [float(np.percentile(means, 2.5)), float(np.percentile(means, 97.5))]


def run_stats():
    with open(os.path.join(OUT, "results_windows.json"), encoding="utf-8") as f:
        rows = json.load(f)
    methods = ["Raw (bandpass)", "LMS adaptive", "Spectral subtraction",
               "Wavelet+IMU", "ICA+IMU", "KISR (proposed)"]
    # per-window paired errors
    def errs_of(m):
        return np.array([abs(w[m] - w["ref"]) for w in rows
                         if w.get(m) is not None], float)

    pair = {}
    kisr_e = errs_of("KISR (proposed)")
    # window-level: align on windows where both exist
    for m in methods:
        if m == "KISR (proposed)":
            continue
        a, b = [], []
        for w in rows:
            if w.get(m) is not None and w.get("KISR (proposed)") is not None:
                a.append(abs(w[m] - w["ref"]))
                b.append(abs(w["KISR (proposed)"] - w["ref"]))
        a, b = np.asarray(a), np.asarray(b)
        d = a - b  # positive -> KISR better
        try:
            wil = sps.wilcoxon(b, a, alternative="two-sided")
            p_win = float(wil.pvalue)
        except Exception:
            p_win = None
        # subject-level aggregation (subject = record prefix sN)
        subj = {}
        for w in rows:
            if w.get(m) is None or w.get("KISR (proposed)") is None:
                continue
            s = w["rec"].split("_")[0]
            subj.setdefault(s, [[], []])
            subj[s][0].append(abs(w[m] - w["ref"]))
            subj[s][1].append(abs(w["KISR (proposed)"] - w["ref"]))
        sm = np.array([[np.mean(v[0]), np.mean(v[1])] for v in subj.values()])
        try:
            wil_s = sps.wilcoxon(sm[:, 1], sm[:, 0], alternative="two-sided")
            p_subj = float(wil_s.pvalue)
        except Exception:
            p_subj = None
        dz = float(d.mean() / (d.std() + 1e-12)) if d.size else None
        pair[m] = {
            "n_windows": int(d.size),
            "mean_diff_kisr_minus_base": float((b - a).mean()),
            "p_window_wilcoxon": p_win,
            "p_subject_wilcoxon": p_subj,
            "n_subjects": int(sm.shape[0]),
            "cohen_dz_window": dz,
            "kisr_mae_ci95": bootstrap_ci(b),
            "base_mae_ci95": bootstrap_ci(a),
            "kisr_mae": float(b.mean()),
            "base_mae": float(a.mean()),
        }
        print(f"  {m:24s} Δ={pair[m]['mean_diff_kisr_minus_base']:+.2f} "
              f"p_w={p_win} p_s={p_subj}", flush=True)

    overall = {}
    for m in methods:
        e = errs_of(m)
        overall[m] = {"mae": float(e.mean()), "ci95": bootstrap_ci(e), "n": int(e.size)}
    return {"overall": overall, "paired_vs_kisr": pair}


# ---------------------------------------------------------------------------
# (3) interference-index mechanism law
# ---------------------------------------------------------------------------
def run_mechanism():
    recs = complete_records()
    data = []  # (overlap_index, err_kisr, err_raw, act)
    for rec_name in recs:
        rec = pl.load_wrist(os.path.join(WRIST, rec_name))
        fs = rec["fs"]
        ppg, imu = rec["ppg"], np.concatenate([rec["acc"], rec["gyro"]], axis=1)
        rp = pl.ecg_rpeaks(rec["ecg"], fs)
        wl, sl = int(WIN_S * fs), int(STEP_S * fs)
        for s in range(0, len(ppg) - wl, sl):
            e = s + wl
            ref = pl.ref_hr(rp, fs, s / fs, e / fs)
            if not np.isfinite(ref) or ref < 40 or ref > 180:
                continue
            p, i = ppg[s:e], imu[s:e]
            # interference index: fraction of cardiac-band bins that fall
            # within tolerance of a kinematic harmonic of the accel fundamental
            nperseg, hop = 256, 64
            mask, freqs, fund = K.motion_subspace(i, fs, nperseg, hop, n_harm=4)
            band = (freqs >= 0.7) & (freqs <= 3.2)
            if not band.any() or mask.shape[0] == 0:
                continue
            # average over frames
            frac = float(np.mean(mask[:, band]))
            # errors from results row
            row = next((w for w in RESULTS_ROWS
                        if w["rec"] == rec_name and abs(w["t"] - s / fs) < 0.01), None)
            if row is None:
                continue
            ek = row.get("KISR (proposed)")
            er = row.get("Raw (bandpass)")
            if ek is None or er is None:
                continue
            data.append((frac, abs(ek - ref), abs(er - ref), row["act"], ref))
    if not data:
        return {}
    frac = np.array([d[0] for d in data])
    ek = np.array([d[1] for d in data])
    er = np.array([d[2] for d in data])
    rho_k, p_k = sps.spearmanr(frac, ek)
    rho_r, p_r = sps.spearmanr(frac, er)
    # activity-stratified correlations (pooled rho can be Simpson-paradoxed)
    by_act = {}
    acts = np.array([d[3] for d in data])
    for a in sorted(set(acts)):
        sel = acts == a
        if sel.sum() >= 10:
            rk, pk = sps.spearmanr(frac[sel], ek[sel])
            rr, pr = sps.spearmanr(frac[sel], er[sel])
            by_act[a] = {"n": int(sel.sum()),
                         "rho_kisr": float(rk), "p_kisr": float(pk),
                         "rho_raw": float(rr), "p_raw": float(pr)}
    # quartile table
    qs = np.percentile(frac, [0, 25, 50, 75, 100])
    qtab = []
    for a, b in zip(qs[:-1], qs[1:]):
        sel = (frac >= a) & (frac <= b + 1e-12)
        qtab.append({"range": [float(a), float(b)],
                     "n": int(sel.sum()),
                     "kisr_mae": float(ek[sel].mean()) if sel.any() else None,
                     "raw_mae": float(er[sel].mean()) if sel.any() else None})
    out = {"n": int(len(data)),
           "spearman_kisr": {"rho": float(rho_k), "p": float(p_k)},
           "spearman_raw": {"rho": float(rho_r), "p": float(p_r)},
           "spearman_by_activity": by_act,
           "quartiles": qtab}
    print(f"  mechanism n={out['n']} rho_kisr={rho_k:.3f} (p={p_k:.2e}) "
          f"rho_raw={rho_r:.3f}", flush=True)
    return out


RESULTS_ROWS = []


def main():
    global RESULTS_ROWS
    with open(os.path.join(OUT, "results_windows.json"), encoding="utf-8") as f:
        RESULTS_ROWS = json.load(f)
    only = sys.argv[1] if len(sys.argv) > 1 else "all"

    if only in ("all", "sensors"):
        print("== sensor-channel ablation", flush=True)
        sens = run_sensor_ablation()
        json.dump(sens, open(os.path.join(OUT, "sensor_ablation.json"), "w"), indent=1)

    if only in ("all", "stats"):
        print("== statistics", flush=True)
        st = run_stats()
        json.dump(st, open(os.path.join(OUT, "stats.json"), "w"), indent=1)

    if only in ("all", "mech"):
        print("== mechanism", flush=True)
        mech = run_mechanism()
        json.dump(mech, open(os.path.join(OUT, "mechanism.json"), "w"), indent=1)
    print("done", flush=True)


if __name__ == "__main__":
    main()
