"""Fig. 9 - Ablation study of the KISR pipeline components.

(a) Component on/off ablations (single-component removal) as delta-MAE bars.
(b) Parameter sweeps: motion-subspace harmonic count, gating strength gate_k,
    and maximum attenuation, all as MAE curves.
Values are read from out/ablation.json produced by src/run_ablation.py.
"""
import os
import sys
import json
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import figstyle as FS
import matplotlib.pyplot as plt

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FIGS = os.path.join(ROOT, "figures")
OUT = os.path.join(ROOT, "out")

FULL = "full KISR"


def main():
    with open(os.path.join(OUT, "ablation.json")) as f:
        ab = json.load(f)["ablation"]

    base = ab[FULL]["mae"]

    fig = plt.figure(figsize=(7.0, 1.47))
    gs = fig.add_gridspec(1, 3, wspace=0.72)

    # ---- (a) component ablations as delta MAE
    ax = fig.add_subplot(gs[0, 0])
    comp = ["no motion subspace", "no coherence gating", "no cardiac protection"]
    labels = ["−sub", "−coh", "−card"]
    deltas = [ab[c]["mae"] - base for c in comp]
    colors = [FS.C["green"] if d < 0 else FS.C["red"] for d in deltas]
    ax.bar(range(len(comp)), deltas, color=colors, edgecolor="black", lw=0.5)
    ax.axhline(0, color="black", lw=0.7)
    ax.set_xticks(range(len(comp)))
    ax.set_xticklabels(labels, fontsize=5.8)
    ax.tick_params(axis="x", pad=1)
    ax.set_ylabel(r"$\Delta$MAE (bpm)", fontsize=7.2)
    for i, d in enumerate(deltas):
        if d < 0:
            ax.text(i, -0.06, f"{d:+.2f}", ha="center", va="top",
                    fontsize=5.6, color="white", fontweight="bold")
        else:
            ax.text(i, 0.06, f"{d:+.2f}", ha="center", va="bottom", fontsize=5.6)
    ax.text(0.98, 0.06, f"full KISR MAE = {base:.2f} bpm",
            transform=ax.transAxes, ha="right", va="bottom", fontsize=5.6)
    ax.text(-0.02, 1.03, "(c)", transform=ax.transAxes, fontsize=8.5,
            fontweight="bold", va="bottom", ha="left")

    # ---- (b) harmonic count sweep
    ax = fig.add_subplot(gs[0, 1])
    hs = [1, 2, 3, 4]
    vals = [ab[f"n_harm={h}"]["mae"] if h != 3 else base for h in hs]
    ax.plot(hs, vals, "o-", color=FS.C["blue"], ms=4)
    ax.axhline(base, color="gray", ls="--", lw=0.8)
    ax.annotate("default", xy=(3, base), xytext=(3.15, base - 0.55),
                fontsize=6, color="gray")
    ax.set_xlabel("harmonic count")
    ax.set_ylabel("MAE (bpm)")
    ax.set_xticks(hs)
    ax.text(0.03, 0.97, "(d)", transform=ax.transAxes, fontsize=8.5,
            fontweight="bold", va="top")

    # ---- (c) gate_k and max_atten
    ax = fig.add_subplot(gs[0, 2])
    gk = [0.5, 1.0, 2.0]
    gv = [ab["gate_k=0.5"]["mae"], base, ab["gate_k=2.0"]["mae"]]
    ma = [0.6, 0.92, 1.0]
    mv = [ab["max_atten=0.6"]["mae"], base, ab["max_atten=1.0"]["mae"]]
    ax.plot(gk, gv, "o-", color=FS.C["red"], ms=4, label=r"gate $k$")
    ax.plot(ma, mv, "s-", color=FS.C["green"], ms=4, label="max attenuation")
    ax.axhline(base, color="gray", ls="--", lw=0.8)
    ax.set_xlabel("parameter value")
    ax.set_ylabel("MAE (bpm)")
    ax.legend(frameon=False, fontsize=5.6, loc="lower left")
    ax.text(0.03, 0.97, "(e)", transform=ax.transAxes, fontsize=8.5,
            fontweight="bold", va="top")

    out = os.path.join(FIGS, "fig9_ablation.png")
    fig.savefig(out, bbox_inches="tight", dpi=950)
    print("saved", out)


if __name__ == "__main__":
    main()
