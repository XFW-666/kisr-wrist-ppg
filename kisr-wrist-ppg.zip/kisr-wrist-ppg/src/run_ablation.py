"""Ablation and design-space study for the KISR paper (Fig. 9 + Fig. 10).

Ablations (Fig. 9): vary one KISR component at a time and quantify its effect
on window-level HR MAE.
  - motion subspace disabled (no IMU harmonics, accel-only mask)
  - coherence gating disabled (uniform suppression inside the mask)
  - frame-local cardiac protection disabled
  - harmonic count of the motion subspace (n_harm = 1..4)

Design space (Fig. 10): sampling-rate decimation and ADC quantisation applied
to the raw PPG before every method, quantifying the accuracy/power trade-off.

All numbers come from real downloaded records; nothing is synthesised.
"""
import os
import sys
import json
import time
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import ppglib as pl
import kisr as K
from run_experiment import complete_records, activity_of, intensity_of, WIN_S, STEP_S, WRIST, OUT


def run_variant(name, method, results):
    """Evaluate a variant on every window. `method(ppg, imu, fs)` returns the
    cleaned PPG and the sampling rate used for HR estimation."""
    recs = complete_records()
    for rec_name in recs:
        rec = pl.load_wrist(os.path.join(WRIST, rec_name))
        fs = rec["fs"]
        ppg, imu = rec["ppg"], np.concatenate([rec["acc"], rec["gyro"]], axis=1)
        rp = pl.ecg_rpeaks(rec["ecg"], fs)
        wl, sl = int(WIN_S * fs), int(STEP_S * fs)
        if len(ppg) < wl + sl:
            continue
        prev = None
        for s in range(0, len(ppg) - wl, sl):
            e = s + wl
            ref = pl.ref_hr(rp, fs, s / fs, e / fs)
            if not np.isfinite(ref) or ref < 40 or ref > 180:
                continue
            p, i = ppg[s:e], imu[s:e]
            try:
                y, fs_used = method(p, i, fs)
                hr, _ = pl.hr_harmonic(y, fs_used, prev=prev)
                if np.isfinite(hr):
                    prev = hr
                if np.isfinite(hr):
                    results.append({"t": round(s / fs, 1), "ref": round(float(ref), 2),
                                    "rec": rec_name, "act": activity_of(rec_name),
                                    "int": intensity_of(rec_name), "mae": abs(float(hr) - ref)})
            except Exception:
                pass


def mae_of(results, filt=None):
    e = [r["mae"] for r in results if filt is None or filt(r)]
    e = np.asarray(e, dtype=float)
    e = e[np.isfinite(e)]
    return {"mae": float(e.mean()) if e.size else None, "n": int(e.size)}


# ---------------- ablation variants (each returns (cleaned, fs)) ----------------
def kisr_variant(**kw):
    def f(p, i, fs):
        return K.kisr(p, i, fs, **kw), fs
    return f


def no_subspace(p, i, fs):
    # replace the kinematic mask with an all-false mask: coherence gating and
    # cardiac protection still run, but nothing is attributed to motion
    orig = K.motion_subspace

    def stub(imu, fs_, nperseg, hop, **kw):
        nf = 1 + max(0, (imu.shape[0] - nperseg)) // hop
        return (np.zeros((max(nf, 1), nperseg // 2 + 1), bool),
                np.fft.rfftfreq(nperseg, d=1.0 / fs_),
                np.zeros(max(nf, 1)))
    K.motion_subspace = stub
    try:
        y = K.kisr(p, i, fs)
    finally:
        K.motion_subspace = orig
    return y, fs


def no_coherence(p, i, fs):
    # uniform suppression: coherence replaced by a constant 1 inside the mask
    orig = K.ppg_motion_coherence

    def stub(ppg_, ref, fs_, nperseg, hop):
        nf = 1 + max(0, (len(ppg_) - nperseg)) // hop
        return np.ones((max(nf, 1), nperseg // 2 + 1))
    K.ppg_motion_coherence = stub
    try:
        y = K.kisr(p, i, fs)
    finally:
        K.ppg_motion_coherence = orig
    return y, fs


def no_cardiac_protection(p, i, fs):
    return K.kisr(p, i, fs, protect_cardiac=False), fs


# ---------------- design-space variants ----------------
def decimate(factor):
    def f(p, i, fs):
        return K.kisr(p[::factor], i[::factor], fs / factor), fs / factor
    return f


def quantize(bits):
    def f(p, i, fs):
        pmax = np.max(np.abs(p)) + 1e-12
        q = np.round(p / pmax * (2 ** (bits - 1) - 1)) / (2 ** (bits - 1) - 1) * pmax
        return K.kisr(q, i, fs), fs
    return f


def native(p, i, fs):
    return K.kisr(p, i, fs), fs


def main():
    t0 = time.time()
    out = {"ablation": {}, "design": {}}

    variants = [
        ("full KISR", native),
        ("no motion subspace", no_subspace),
        ("no coherence gating", no_coherence),
        ("no cardiac protection", no_cardiac_protection),
        ("n_harm=1", kisr_variant(n_harm=1)),
        ("n_harm=2", kisr_variant(n_harm=2)),
        ("n_harm=4", kisr_variant(n_harm=4)),
        ("gate_k=0.5", kisr_variant(gate_k=0.5)),
        ("gate_k=2.0", kisr_variant(gate_k=2.0)),
        ("max_atten=0.6", kisr_variant(max_atten=0.6)),
        ("max_atten=1.0", kisr_variant(max_atten=1.0)),
    ]
    for name, fn in variants:
        res = []
        run_variant(name, fn, res)
        out["ablation"][name] = mae_of(res)
        print(f"  ablation {name:24s} MAE={out['ablation'][name]['mae']}  n={out['ablation'][name]['n']}")

    designs = [
        ("fs=64 Hz", decimate(8)),
        ("fs=32 Hz", decimate(16)),
        ("fs=16 Hz", decimate(32)),
        ("8-bit", quantize(8)),
        ("10-bit", quantize(10)),
        ("12-bit", quantize(12)),
        ("16-bit (native)", native),
    ]
    for name, fn in designs:
        res = []
        run_variant(name, fn, res)
        out["design"][name] = mae_of(res)
        print(f"  design   {name:24s} MAE={out['design'][name]['mae']}  n={out['design'][name]['n']}")

    os.makedirs(OUT, exist_ok=True)
    with open(os.path.join(OUT, "ablation.json"), "w") as f:
        json.dump(out, f, indent=1)
    print(f"elapsed {time.time()-t0:.1f}s -> out/ablation.json")


if __name__ == "__main__":
    main()
