"""Publication-quality sensor concept diagrams (SVG → PNG via svglib).

Three new figures rich in sensor content:
  fig13_node_anatomy.png, cross-section of the wrist node: 8 sensors placed,
                            each with range/bus/dataset-channel call-outs.
  fig14_optics.png, PPG physics: skin layers, photon paths for green/IR,
                            pulsatile perfusion vs. motion/contact artifacts,
                            ambient leakage, the physical failure taxonomy.
  fig15_sensor_matrix.png, sensor × purpose matrix as a styled concept map
                            tying every sensor to what it protects against.
Plus high-quality redraughts used elsewhere in the manuscript.
"""
import os
import sys
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import figstyle as FS
import svgkit as SK

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FIGS = os.path.join(ROOT, "figures")
OUT = os.path.join(ROOT, "out")
os.makedirs(FIGS, exist_ok=True)


# ---------------------------------------------------------------------------
# Fig 13: wrist node anatomy (cross-section + call-outs)
# ---------------------------------------------------------------------------
def fig13_node_anatomy():
    W, H = 720, 520
    s = [SK.svg_open(W, H, "#F8FAFC")]

    s.append(SK.label(W / 2, 26, "Wrist sensing node: cross-section and sensor map", 15, "#101828", "middle", "bold"))
    s.append(SK.label(W / 2, 44, "Skin side (bottom) carries the optical stack; PCB top carries the motion & context sensors", 9.5, "#667085"))

    # ---------- left: cross-section stack
    x0, y0 = 60, 70
    s.append(SK.label(x0 + 150, y0 - 8, "(d) Cross-section", 11, "#344054", "middle", "bold"))

    # top cover
    s.append(SK.card(x0, y0 + 10, 300, 34, "#E4E7EC", "#98A2B3", 10, 1.2))
    s.append(SK.label(x0 + 150, y0 + 31, "Top cover (polycarbonate) + 2.4 GHz antenna window", 9, "#344054"))

    # PCB
    s.append(SK.card(x0, y0 + 52, 300, 96, "#D1FADF", "#12B76A", 8, 1.6))
    s.append(SK.label(x0 + 150, y0 + 66, "4-layer PCB (0.8 mm)", 9, "#027A48", "middle", "bold"))

    # chips on PCB (top-view sprites as rounded rects)
    chips = [
        (x0 + 18,  y0 + 78,  52, 28, "IMU", "acc×2+gyro", "#EEF2FF", "#6366F1"),
        (x0 + 80,  y0 + 78,  44, 28, "MAG", "3-axis", "#EEF2FF", "#6366F1"),
        (x0 + 134, y0 + 78,  40, 28, "TEMP", "±0.1 °C", "#FEF3C7", "#F59E0B"),
        (x0 + 184, y0 + 78,  40, 28, "ALS", "ambient", "#FEF3C7", "#F59E0B"),
        (x0 + 234, y0 + 78,  52, 28, "BARO", "1 hPa", "#FEF3C7", "#F59E0B"),
    ]
    for cx, cy, cw, ch, t1, t2, f, st in chips:
        s.append(SK.card(cx, cy, cw, ch, f, st, 5, 1.1))
        s.append(SK.label(cx + cw / 2, cy + 11, t1, 7.5, "#1F2937", "middle", "bold"))
        s.append(SK.label(cx + cw / 2, cy + 21, t2, 6.5, "#6B7280"))
    # MCU BLE
    s.append(SK.card(x0 + 20, y0 + 112, 110, 28, "#EDE9FE", "#7C3AED", 5, 1.2))
    s.append(SK.label(x0 + 75, y0 + 130, "MCU + BLE SoC", 8, "#5B21B6", "middle", "bold"))
    # PPG AFE
    s.append(SK.card(x0 + 150, y0 + 112, 130, 28, "#FEE2E2", "#EF4444", 5, 1.2))
    s.append(SK.label(x0 + 215, y0 + 130, "PPG AFE (green + IR)", 8, "#B91C1C", "middle", "bold"))

    # mid housing / optical cavity
    s.append(SK.card(x0, y0 + 156, 300, 40, "#F2F4F7", "#98A2B3", 8, 1.2))
    s.append(SK.label(x0 + 150, y0 + 180, "Optical cavity  ·  black silicone gasket  ·  ECG pad header (3)", 8.5, "#344054"))

    # optical window block
    s.append(SK.card(x0 + 60, y0 + 204, 180, 52, "#FFF7ED", "#FB923C", 10, 1.4))
    s.append(SK.label(x0 + 150, y0 + 218, "Optical window", 9, "#C2410C", "middle", "bold"))
    # LEDs + PD inside
    s.append(SK.card(x0 + 74, y0 + 226, 40, 22, "#86EFAC", "#15803D", 4, 1.0))
    s.append(SK.label(x0 + 94, y0 + 241, "G 525", 7, "#14532D"))
    s.append(SK.card(x0 + 130, y0 + 226, 40, 22, "#FDBA74", "#C2410C", 4, 1.0))
    s.append(SK.label(x0 + 150, y0 + 241, "IR 940", 7, "#7C2D12"))
    s.append(SK.card(x0 + 186, y0 + 226, 40, 22, "#BFDBFE", "#2563EB", 4, 1.0))
    s.append(SK.label(x0 + 206, y0 + 241, "PD", 7, "#1E3A8A"))

    # skin
    s.append(SK.card(x0 - 6, y0 + 264, 312, 46, "#FBD5B5", "#D97706", 8, 1.2))
    s.append(SK.label(x0 + 150, y0 + 292, "Skin / dermal microvasculature (perfusion pulsation)", 9, "#92400E"))

    # light arrows
    s.append(SK.arrow(x0 + 94, y0 + 250, x0 + 120, y0 + 275, "#15803D", 1.6))
    s.append(SK.arrow(x0 + 150, y0 + 250, x0 + 132, y0 + 275, "#C2410C", 1.6))
    s.append(SK.arrow(x0 + 120, y0 + 275, x0 + 206, y0 + 250, "#2563EB", 1.4))
    s.append(SK.arrow(x0 + 132, y0 + 275, x0 + 200, y0 + 250, "#2563EB", 1.4))

    # ---------- right: sensor call-out cards
    xr, yr = 400, 70
    s.append(SK.label(xr + 150, yr - 8, "(e) Sensor suite and dataset mapping", 11, "#344054", "middle", "bold"))
    rows = [
        ("Green PPG 525 nm", "HR channel  ·  wrist_ppg", "#DCFCE7", "#166534"),
        ("IR PPG 940 nm", "dual-λ / ambient-robust", "#FFEDD5", "#9A3412"),
        ("Wide-range accel ±32 g", "impacts  ·  wide_range_accelerometer", "#E0E7FF", "#3730A3"),
        ("Low-noise accel ±8 g", "fine motion  ·  low_noise_accelerometer", "#E0E7FF", "#3730A3"),
        ("Gyro ±2000 dps", "rotation artifacts  ·  wrist_gyro", "#E0E7FF", "#3730A3"),
        ("Magnetometer ±4 G", "orientation  ·  wrist_mag", "#E0E7FF", "#3730A3"),
        ("Skin temp TMP117-class", "perfusion context (node-only)", "#FEF3C7", "#92400E"),
        ("ALS + proximity", "ambient leakage gate (node-only)", "#FEF3C7", "#92400E"),
        ("Barometer", "climb / activity context (node-only)", "#FEF3C7", "#92400E"),
        ("ECG 3-pad header", "ground truth  ·  chest_ecg", "#FFE4E6", "#9F1239"),
    ]
    for i, (t, sub, f, st) in enumerate(rows):
        yy = yr + 8 + i * 38
        s.append(SK.card(xr, yy, 300, 32, f, st, 8, 1.0))
        s.append(SK.label(xr + 10, yy + 13, t, 9, st, "start", "bold"))
        s.append(SK.label(xr + 10, yy + 25, sub, 7.5, "#475467", "start"))

    s.append(SK.svg_close())
    out = os.path.join(FIGS, "fig13_node_anatomy.png")
    SK.svg_to_png("\n".join(s), out, dpi=220)
    print("saved", out)


# ---------------------------------------------------------------------------
# Fig 14: PPG optics & failure physics
# ---------------------------------------------------------------------------
def fig14_optics():
    W, H = 720, 460
    s = [SK.svg_open(W, H, "#FFFBEB")]
    s.append(SK.label(W / 2, 26, "PPG sensing physics and the motion-artifact pathway", 15, "#101828", "middle", "bold"))
    s.append(SK.label(W / 2, 44, "What the photodiode actually receives: pulsatile perfusion (wanted) + four artifact channels (unwanted)", 9.5, "#667085"))

    # skin slab
    s.append(SK.card(60, 70, 360, 300, "#FBD5B5", "#D97706", 16, 1.4))
    s.append(SK.label(240, 92, "Skin cross-section", 11, "#92400E", "middle", "bold"))
    # epidermis
    s.append(SK.card(72, 104, 336, 40, "#FDE68A", "#F59E0B", 8, 1.0))
    s.append(SK.label(240, 128, "Epidermis (scattering layer)", 9, "#92400E"))
    # dermis with vessels
    s.append(SK.card(72, 152, 336, 130, "#FECACA", "#EF4444", 8, 1.0))
    s.append(SK.label(150, 172, "Dermis: arteriolar / capillary bed", 9, "#9F1239", "start"))
    vessels = [(115, 215), (175, 245), (325, 245), (385, 215)]
    for vx, vy in vessels:
        s.append(f'<ellipse cx="{vx}" cy="{vy}" rx="15" ry="8" fill="#DC2626" opacity="0.75"/>')
        s.append(SK.label(vx, vy + 3, "RBC", 6, "#FFF", "middle", "bold"))
    s.append(SK.label(240, 268, "blood-volume pulsation  dV(t)  <--  cardiac source", 9, "#9F1239", "middle", "bold"))
    # subcut
    s.append(SK.card(72, 290, 336, 62, "#E7D5B8", "#A16207", 8, 1.0))
    s.append(SK.label(240, 322, "Subcutaneous tissue / venous pooling (slow drift)", 9, "#78350F"))

    # LED and PD
    s.append(SK.card(40, 150, 44, 30, "#86EFAC", "#15803D", 6, 1.2))
    s.append(SK.label(62, 169, "LED", 9, "#14532D", "middle", "bold"))
    s.append(SK.card(432, 150, 44, 30, "#BFDBFE", "#2563EB", 6, 1.2))
    s.append(SK.label(454, 169, "PD", 9, "#1E3A8A", "middle", "bold"))

    # photon paths (green: shallow; IR: deeper), polylines
    s.append('<path d="M84 160 C 140 140, 190 165, 250 185 S 370 180, 432 158" '
             'stroke="#15803D" stroke-width="2.2" fill="none" opacity="0.9"/>')
    s.append('<line x1="90" y1="60" x2="130" y2="60" stroke="#15803D" stroke-width="2.2"/>')
    s.append(SK.label(136, 63, "green 525 nm: shallow (HR)", 8, "#15803D", "start"))
    s.append('<line x1="300" y1="60" x2="340" y2="60" stroke="#C2410C" stroke-width="2.2"/>')
    s.append(SK.label(346, 63, "IR 940 nm: deep (SpO2)", 8, "#C2410C", "start"))
    s.append('<path d="M84 182 C 150 215, 200 255, 255 255 S 380 225, 432 178" '
             'stroke="#C2410C" stroke-width="2.2" fill="none" opacity="0.85"/>')


    # artifact channels on the right
    xr = 500
    s.append(SK.label(xr + 100, 70, "(b) Artifact channels at the PD", 10.5, "#344054", "middle", "bold"))
    arts = [
        ("1. Contact modulation", "strap bounce changes LED–PD\ncoupling → step + spike noise", "#FEE2E2", "#B91C1C"),
        ("2. Motion harmonics", "limb periodicity mixes into the\ncardiac band (0.7–3.2 Hz)", "#E0E7FF", "#3730A3"),
        ("3. Venous pooling", "non-pulsatile blood shift →\nbaseline wander", "#FECACA", "#9F1239"),
        ("4. Ambient leakage", "sunlight / lamps couple through\nthe gasket into the PD", "#FEF3C7", "#92400E"),
        ("Wanted: perfusion ΔV", "arterial pulsation, the only\ncomponent we want to keep", "#DCFCE7", "#166534"),
    ]
    for i, (t, body, f, st) in enumerate(arts):
        yy = 84 + i * 68
        s.append(SK.card(xr, yy, 200, 58, f, st, 10, 1.1))
        s.append(SK.label(xr + 12, yy + 16, t, 9, st, "start", "bold"))
        for j, ln in enumerate(body.split("\n")):
            s.append(SK.label(xr + 12, yy + 30 + j * 11, ln, 7.3, "#475467", "start"))

    s.append(SK.svg_close())
    out = os.path.join(FIGS, "fig14_optics.png")
    SK.svg_to_png("\n".join(s), out, dpi=220)
    print("saved", out)


# ---------------------------------------------------------------------------
# Fig 15: real multi-sensor waveforms (data figure, matplotlib)
# ---------------------------------------------------------------------------
def fig15_sensor_waveforms():
    import ppglib as pl
    import matplotlib.pyplot as plt

    rec = pl.load_wrist(os.path.join(ROOT, "data", "wrist", "s1_walk"))
    fs = rec["fs"]
    # pick 12 s starting at a walking segment
    t0 = int(20 * fs)
    dur = int(12 * fs)
    sl = slice(t0, t0 + dur)
    t = np.arange(dur) / fs

    panels = [
        ("Chest ECG (reference)", rec["ecg"][sl], FS.C["orange"]),
        ("Wrist PPG", rec["ppg"][sl], FS.C["red"]),
        ("Accel: wide-range (x)", rec["acc"][sl][:, 0], FS.C["blue"]),
        ("Accel: low-noise (x)", rec["acc_ln"][sl][:, 0], FS.C["sky"]),
        ("Gyroscope (x)", rec["gyro"][sl][:, 0], FS.C["purple"]),
        ("Magnetometer (x)", rec["mag"][sl][:, 0], FS.C["green"]),
    ]
    fig, axes = plt.subplots(len(panels), 1, figsize=(7.0, 4.8), sharex=True)
    fig.subplots_adjust(hspace=0.26, left=0.18, right=0.98, top=0.95, bottom=0.08)
    from matplotlib.ticker import MaxNLocator
    for ax, (name, y, col) in zip(axes, panels):
        y = y - np.mean(y)
        ax.plot(t, y, color=col, lw=0.7)
        ax.set_ylabel(name, fontsize=7.2, rotation=0, ha="right", va="center", labelpad=8)
        ax.tick_params(labelsize=6)
        ax.yaxis.set_major_locator(MaxNLocator(3, prune="both"))
        for sp in ("top", "right"):
            ax.spines[sp].set_visible(False)
        ax.set_xlim(0, dur / fs)
    axes[-1].set_xlabel("Time (s)", fontsize=8)
    axes[0].set_title(
        "Simultaneous multi-sensor stream from the wrist node (record s1_walk, 12 s window)",
        fontsize=9, loc="left")
    out = os.path.join(FIGS, "fig15_sensor_waveforms.png")
    fig.savefig(out, bbox_inches="tight", dpi=950)
    print("saved", out)


if __name__ == "__main__":
    fig13_node_anatomy()
    fig14_optics()
    fig15_sensor_waveforms()
