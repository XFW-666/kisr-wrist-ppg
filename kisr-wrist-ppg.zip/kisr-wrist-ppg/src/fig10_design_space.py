"""Fig. 10 - Sensing-front-end design space: sampling rate and ADC resolution.

(a) MAE vs. sampling rate after decimation of the raw PPG (IMU kept native).
(b) MAE vs. ADC quantisation bit depth.
(c) Effective data-rate / energy proxy vs. configuration.
All values from out/ablation.json "design" block (real signals, real decimation).
"""
import os
import sys
import json
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import figstyle as FS
import matplotlib.pyplot as plt

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FIGS = os.path.join(ROOT, "figures")
OUT = os.path.join(ROOT, "out")


def main():
    with open(os.path.join(OUT, "ablation.json")) as f:
        ds = json.load(f)["design"]

    fs_cfg = [("fs=16 Hz", 16), ("fs=32 Hz", 32), ("fs=64 Hz", 64)]
    fig = plt.figure(figsize=(7.0, 1.65))
    gs = fig.add_gridspec(1, 3, wspace=0.42)

    # ---- (a) sampling rate: only 64 Hz resolves the HR band
    ax = fig.add_subplot(gs[0, 0])
    fsv = np.array([c[1] for c in fs_cfg], float)
    mae = np.array([np.nan if ds[n]["mae"] is None else ds[n]["mae"]
                    for n, _ in fs_cfg], float)
    ok = np.array([ds[n]["n"] > 0 for n, _ in fs_cfg])
    ax.axvspan(11, 45, color="#ececec", zorder=0)
    ax.text(28, 36.2, "HR not\nresolvable", fontsize=5.8,
            color="#777777", ha="center", va="center")
    ax.plot(fsv[ok], mae[ok], "o", color=FS.C["blue"], ms=6, zorder=3)
    for x, y in zip(fsv[ok], mae[ok]):
        ax.annotate(f"{y:.1f}", (x, y), xytext=(-8, 4),
                    textcoords="offset points", fontsize=6.2,
                    color=FS.C["blue"], ha="right")
    ax.set_xticks(fsv)
    ax.set_xticklabels([f"{int(v)}" for v in fsv])
    ax.set_xlabel("PPG sampling rate (Hz)")
    ax.set_ylabel("MAE (bpm)")
    ax.set_xlim(11, 72)
    ax.set_ylim(34, 41)
    ax.text(-0.40, 1.16, "(a)", transform=ax.transAxes, fontsize=9, fontweight="bold")

    # ---- (b) ADC resolution
    ax = fig.add_subplot(gs[0, 1])
    bits = [8, 10, 12, 16]
    bv = [ds["8-bit"]["mae"], ds["10-bit"]["mae"], ds["12-bit"]["mae"],
          ds["16-bit (native)"]["mae"]]
    ax.plot(bits, bv, "s-", color=FS.C["green"], ms=4)
    native_mae = ds["16-bit (native)"]["mae"]
    ax.axhline(native_mae, color="gray", ls="--", lw=0.8)
    ax.set_xticks(bits)
    ax.set_xlabel("ADC resolution (bit)")
    ax.set_ylabel("MAE (bpm)")
    ax.set_ylim(min(bv) - 0.8, max(bv) + 0.8)
    ax.text(-0.40, 1.16, "(b)", transform=ax.transAxes, fontsize=9, fontweight="bold")

    # ---- (c) cost proxy
    ax = fig.add_subplot(gs[0, 2])
    pts = [("16-bit", 64 * 16, native_mae),
           ("12-bit", 64 * 12, ds["12-bit"]["mae"]),
           ("10-bit", 64 * 10, ds["10-bit"]["mae"]),
           ("8-bit", 64 * 8, ds["8-bit"]["mae"])]
    cost = [p[1] for p in pts]
    mae3 = [p[2] for p in pts]
    ax.plot(cost, mae3, "o-", color=FS.C["purple"], ms=4)
    for i, (p, c, m) in enumerate(pts):
        yoff = 11 if i % 2 == 0 else -17
        ha = "center"
        if c == max(cost):
            ha = "right"
        elif c == min(cost):
            ha = "left"
        ax.annotate(p, (c, m), fontsize=5.8, xytext=(0, yoff),
                    textcoords="offset points", ha=ha)
    ax.set_xlabel("throughput proxy (Hz $\\times$ bit)")
    ax.set_ylabel("MAE (bpm)")
    ax.set_xlim(400, 1150)
    ax.set_ylim(min(mae3) - 0.9, max(mae3) + 0.9)
    ax.text(-0.40, 1.16, "(c)", transform=ax.transAxes, fontsize=9, fontweight="bold")

    out = os.path.join(FIGS, "fig10_design_space.png")
    fig.savefig(out, bbox_inches="tight", dpi=950)
    print("saved", out)


if __name__ == "__main__":
    main()
