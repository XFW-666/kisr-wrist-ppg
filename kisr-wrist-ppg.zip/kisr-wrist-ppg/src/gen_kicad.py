"""Generate a KiCad-10-valid schematic (.kicad_sch) for the multi-sensor wrist
node and render it with kicad-cli to PNG.

Format notes (KiCad 8/9/10 eeschema sexp):
  - lib_id is "Library:Symbol"; the same name is the key under lib_symbols
  - symbol units use "<name>_<unit>_<style>" (style 1 = drawn)
  - pin electrical_type tokens: input output bidirectional tri_state passive
    free unspecified power_in power_out open_collector open_emitter no_connect
"""
import os
import subprocess
import uuid

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
HW = os.path.join(ROOT, "hardware")
FIGS = os.path.join(ROOT, "figures")
os.makedirs(HW, exist_ok=True)

LIB = "wristnode"
ROOT_UUID = "5f2d7a10-0000-4000-8000-000000000001"
KICAD_CLI = os.path.join(os.environ.get("LOCALAPPDATA", ""),
                         "Programs", "KiCad", "10.99", "bin", "kicad-cli.exe")

# name, ref, pins [(pin_name, pin_num, side, elec)], size(w,h)
SYMBOLS = [
    ("PPG_AFE", "U", [
        ("LED_K", "1", "L", "passive"), ("LED_A", "2", "L", "passive"),
        ("PD_A", "3", "L", "passive"), ("PD_K", "4", "L", "passive"),
        ("SCLK", "5", "L", "input"), ("SDI", "6", "L", "input"),
        ("SDO", "7", "R", "output"), ("CS", "8", "L", "input"),
        ("VDD", "9", "R", "power_in"), ("GND", "10", "L", "power_in"),
    ], 25, 32),
    ("ACC_WIDE", "U", [
        ("SDA", "1", "L", "bidirectional"), ("SCL", "2", "L", "input"),
        ("INT1", "3", "R", "output"), ("VDD", "4", "R", "power_in"),
        ("GND", "5", "L", "power_in"),
    ], 18, 20),
    ("ACC_LN", "U", [
        ("SDA", "1", "L", "bidirectional"), ("SCL", "2", "L", "input"),
        ("INT2", "3", "R", "output"), ("VDD", "4", "R", "power_in"),
        ("GND", "5", "L", "power_in"),
    ], 18, 20),
    ("GYRO", "U", [
        ("SDA", "1", "L", "bidirectional"), ("SCL", "2", "L", "input"),
        ("INT", "3", "R", "output"), ("VDD", "4", "R", "power_in"),
        ("GND", "5", "L", "power_in"),
    ], 18, 20),
    ("MAG", "U", [
        ("SDA", "1", "L", "bidirectional"), ("SCL", "2", "L", "input"),
        ("DRDY", "3", "R", "output"), ("VDD", "4", "R", "power_in"),
        ("GND", "5", "L", "power_in"),
    ], 18, 20),
    ("TEMP", "U", [
        ("SDA", "1", "L", "bidirectional"), ("SCL", "2", "L", "input"),
        ("ALERT", "3", "R", "output"), ("VDD", "4", "R", "power_in"),
        ("GND", "5", "L", "power_in"),
    ], 16, 18),
    ("ALS", "U", [
        ("SDA", "1", "L", "bidirectional"), ("SCL", "2", "L", "input"),
        ("INT", "3", "R", "output"), ("VDD", "4", "R", "power_in"),
        ("GND", "5", "L", "power_in"),
    ], 16, 18),
    ("BARO", "U", [
        ("SDA", "1", "L", "bidirectional"), ("SCL", "2", "L", "input"),
        ("VDD", "3", "R", "power_in"), ("GND", "4", "L", "power_in"),
    ], 16, 16),
    ("MCU_BLE", "U", [
        ("I2C_SCL", "1", "L", "bidirectional"), ("I2C_SDA", "2", "L", "bidirectional"),
        ("SPI_SCK", "3", "L", "input"), ("SPI_MOSI", "4", "L", "input"),
        ("SPI_MISO", "5", "R", "output"), ("SPI_CS", "6", "L", "input"),
        ("SWDIO", "7", "L", "bidirectional"), ("SWCLK", "8", "L", "input"),
        ("ANT", "9", "R", "output"), ("VDD", "10", "R", "power_in"),
        ("GND", "11", "L", "power_in"),
    ], 28, 34),
    ("ECG_HD", "J", [
        ("RA", "1", "L", "passive"), ("LA", "2", "L", "passive"),
        ("RL", "3", "L", "passive"),
    ], 16, 16),
    ("LDO", "U", [
        ("VIN", "1", "L", "power_in"), ("GND", "2", "L", "power_in"),
        ("VOUT", "3", "R", "power_out"), ("EN", "4", "L", "input"),
    ], 16, 14),
]

# (lib_name, ref, value, x, y)
PLACEMENTS = [
    # two large blocks stacked on the left
    ("MCU_BLE", "U9", "nRF52840", 52, 52),
    ("PPG_AFE", "U1", "AFE4400", 52, 108),
    # nine small blocks in a 3 x 3 grid on the right
    ("ACC_WIDE", "U2", "ICM-42688-P", 160, 42),
    ("ACC_LN", "U3", "LSM6DSV", 160, 78),
    ("GYRO", "U4", "LSM6DSV-G", 160, 114),
    ("MAG", "U5", "LIS3MDL", 212, 42),
    ("ALS", "U7", "MAX86176", 212, 78),
    ("TEMP", "U6", "TMP117", 212, 114),
    ("BARO", "U8", "LPS22HH", 264, 42),
    ("ECG_HD", "J1", "ECG_PADS", 264, 78),
    ("LDO", "U10", "TPS7A02", 264, 114),
]


def lib_symbol(name, ref, pins, w, h):
    hw, hh = w / 2, h / 2
    lines = [
        f'    (symbol "{LIB}:{name}" (pin_numbers hide) (pin_names (offset 1.016)) '
        f'(exclude_from_sim no) (in_bom yes) (on_board yes)',
        f'      (property "Reference" "{ref}" (at {-hw} {hh + 1.27} 0) '
        f'(effects (font (size 1.27 1.27))))',
        f'      (property "Value" "{name}" (at {hw} {hh + 1.27} 0) '
        f'(effects (font (size 1.27 1.27))))',
        f'      (property "Footprint" "" (at 0 0 0) (effects (font (size 1.27 1.27)) hide))',
        f'      (property "Datasheet" "" (at 0 0 0) (effects (font (size 1.27 1.27)) hide))',
        f'      (symbol "{name}_0_1"',
        f'        (rectangle (start {-hw} {hh}) (end {hw} {-hh}) '
        f'(stroke (width 0.254) (type default)) (fill (type background))))',
        f'      (symbol "{name}_1_1"',
    ]
    left = [p for p in pins if p[2] == "L"]
    right = [p for p in pins if p[2] == "R"]
    for i, (pname, pnum, side, elec) in enumerate(left):
        yy = hh - 2.54 - i * 2.54
        lines.append(f'        (pin {elec} line (at {-hw - 5.08} {yy:.2f} 0) (length 5.08)')
        lines.append(f'          (name "{pname}" (effects (font (size 1.27 1.27))))')
        lines.append(f'          (number "{pnum}" (effects (font (size 1.27 1.27)))))')
    for i, (pname, pnum, side, elec) in enumerate(right):
        yy = hh - 2.54 - i * 2.54
        lines.append(f'        (pin {elec} line (at {hw + 5.08} {yy:.2f} 180) (length 5.08)')
        lines.append(f'          (name "{pname}" (effects (font (size 1.27 1.27))))')
        lines.append(f'          (number "{pnum}" (effects (font (size 1.27 1.27)))))')
    lines.append('      ))')
    return "\n".join(lines)


def make_sch():
    sym_defs = "\n".join(lib_symbol(n, r, p, w, h) for (n, r, p, w, h) in SYMBOLS)

    insts = []
    for i, (lib, ref, val, x, y) in enumerate(PLACEMENTS):
        u = f"aaaaaaaa-0000-4000-8000-{i:012d}"
        pins = next(p for (n, r, p, w, h) in SYMBOLS if n == lib)
        hh = next(hh for (n, r, p, w, hh) in SYMBOLS if n == lib) / 2
        pin_uuids = "\n".join(
            f'    (pin "{num}" (uuid "bbbbbbbb-0000-4000-8000-{i:012d}{num}"))'
            for (_, num, _, _) in pins)
        insts.append(f'''  (symbol (lib_id "{LIB}:{lib}") (at {x} {y} 0) (unit 1)
    (exclude_from_sim no) (in_bom yes) (on_board yes) (dnp no)
    (uuid "{u}")
    (property "Reference" "{ref}" (at {x} {y - hh - 2.8:.1f} 0) (effects (font (size 1.27 1.27))))
    (property "Value" "{val}" (at {x} {y + hh + 2.8:.1f} 0) (effects (font (size 1.27 1.27))))
    (property "Footprint" "" (at {x} {y} 0) (effects (font (size 1.27 1.27)) hide))
    (property "Datasheet" "" (at {x} {y} 0) (effects (font (size 1.27 1.27)) hide))
{pin_uuids}
    (instances
      (project "wrist_node"
        (path "/{ROOT_UUID}"
          (reference "{ref}") (unit 1)))))''')

    labels = []
    # White-list net labels: only buses that actually connect across parts.
    # Sensor pins named SDA/SCL are labelled as I2C_SDA/I2C_SCL so the same
    # global net joins them to the MCU's I2C_* pins.
    sym_by_name = {n: (r, p, w, h) for (n, r, p, w, h) in SYMBOLS}
    li = 0
    for (lib, ref, val, x, y) in PLACEMENTS:
        _, pins, w, h = sym_by_name[lib]
        hw, hh = w / 2, h / 2
        left = [pp for pp in pins if pp[2] == "L"]
        right = [pp for pp in pins if pp[2] == "R"]
        for side, plist, sx, ang, just in (
            ("L", left, -1, 180, "right"),
            ("R", right, 1, 0, "left"),
        ):
            for k, (pname, pnum, _, elec) in enumerate(plist):
                net = None
                if pname in ("SDA",) or pname == "I2C_SDA":
                    net = "I2C_SDA"
                elif pname in ("SCL",) or pname == "I2C_SCL":
                    net = "I2C_SCL"
                elif pname in ("SCLK", "SPI_SCK"):
                    net = "SPI_SCK"
                elif pname in ("SDI", "SPI_MOSI"):
                    net = "SPI_MOSI"
                elif pname in ("SDO", "SPI_MISO"):
                    net = "SPI_MISO"
                elif pname in ("CS", "SPI_CS"):
                    net = "SPI_CS"
                elif pname in ("SWDIO", "SWCLK", "ANT", "RA", "LA", "RL"):
                    net = pname
                if net is None:
                    continue
                py = y + hh - 2.54 - k * 2.54
                px = x + sx * (hw + 5.08)
                # ECG pads: labels hang to the RIGHT of the pin (into free space)
                if pname in ("RA", "LA", "RL"):
                    ang, just = 0, "left"
                else:
                    ang, just = (180, "right") if side == "L" else (0, "left")
                labels.append(f'''  (global_label "{net}" (shape input) (at {px:.2f} {py:.2f} {ang})
    (effects (font (size 1.0 1.0)) (justify {just}))
    (uuid "dddddddd-0000-4000-8000-{li:012d}")
    (property "Intersheetrefs" "${{INTERSHEET_REFS}}" (at {px:.2f} {py:.2f} 0)
      (effects (font (size 1.0 1.0)) hide)))''')
                li += 1

    text = '''  (text "KISR wrist sensing node - multi-sensor front end\\nDual-wavelength PPG AFE + dual-range accel + gyro + mag + temp + ALS + baro + ECG\\nImport to JLC EasyEDA Pro: File > Import > KiCad"
    (exclude_from_sim no) (at 12 148 0)
    (effects (font (size 1.8 1.8)) (justify left bottom))
    (uuid "eeeeeeee-0000-4000-8000-000000000001"))'''

    doc = f'''(kicad_sch (version 20250114) (generator "kisr_paper_gen") (generator_version "9.0")
  (uuid "{ROOT_UUID}")
  (paper "A4")
  (title_block
    (title "KISR Wrist Sensing Node - Multi-Sensor Front End")
    (date "2026-09-24")
    (rev "A")
    (company "IEEE Sensors Journal submission")
    (comment 1 "Schematic-level; footprints assigned in PCB editor")
    (comment 2 "Sensor suite mirrors and extends the PhysioNet wrist modality set")
  )
  (lib_symbols
{sym_defs}
  )
{chr(10).join(insts)}
{chr(10).join(labels)}
{text}
  (sheet_instances
    (path "/" (page "1")))
)
'''
    path = os.path.join(HW, "wrist_node.kicad_sch")
    with open(path, "w", encoding="utf-8") as f:
        f.write(doc)
    return path


def render(path):
    out_png = os.path.join(FIGS, "fig11b_kicad_schematic.png")
    cmd = [KICAD_CLI, "sch", "export", "png",
           "--output", FIGS, "--dpi", "900",
           "--exclude-drawing-sheet", path]
    r = subprocess.run(cmd, capture_output=True, timeout=120,
                       encoding="utf-8", errors="replace")
    print("kicad-cli rc:", r.returncode)
    if r.stdout:
        print("STDOUT:", r.stdout[-800:])
    if r.stderr:
        print("STDERR:", r.stderr[-800:])
    # exported name follows the sch basename
    exported = os.path.join(FIGS, "wrist_node.png")
    if os.path.exists(exported):
        os.replace(exported, out_png)
    if os.path.exists(out_png):
        crop_to_content(out_png)
    return out_png if os.path.exists(out_png) else None


def crop_to_content(png_path, margin=24):
    """Tight-crop the A4 render around inked content; kills dead page margins."""
    from PIL import Image
    import numpy as np
    im = Image.open(png_path).convert("RGB")
    a = np.asarray(im)
    bg = a[5, 5]
    diff = (a.astype(int) - bg.astype(int)).any(axis=2)
    ys, xs = np.where(diff)
    if len(xs) == 0:
        return
    x0, x1 = max(xs.min() - margin, 0), min(xs.max() + margin, a.shape[1])
    y0, y1 = max(ys.min() - margin, 0), min(ys.max() + margin, a.shape[0])
    im.crop((x0, y0, x1, y1)).save(png_path)
    print("cropped", png_path, (x1 - x0, y1 - y0))


if __name__ == "__main__":
    p = make_sch()
    print("wrote", p)
    png = render(p)
    print("png:", png)
