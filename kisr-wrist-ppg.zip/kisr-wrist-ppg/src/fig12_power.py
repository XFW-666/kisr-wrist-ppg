"""Fig. 12 - End-to-end deployment and power model for the custom wrist node.

(a) Processing timeline of one KISR update cycle on the node.
(b) Modeled energy breakdown per hour for the sensing front end and MCU
    (budget model from component datasheet-class figures; labeled as a model,
    not a measurement).
(c) Battery life vs. duty-cycle configuration from the same budget model.

All hardware numbers are engineering estimates for the design described in
Fig. 11, clearly labeled as a model.
"""
import os
import sys
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import figstyle as FS
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FIGS = os.path.join(ROOT, "figures")


def box(ax, x, y, w, h, text, fc, fs=5.8, ec="black"):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.01",
                                fc=fc, ec=ec, lw=0.6))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fs)


def main():
    fig = plt.figure(figsize=(7.0, 4.0))
    gs = fig.add_gridspec(2, 2, height_ratios=[1.0, 1.15], hspace=0.42, wspace=0.32)

    # ---- (d) timeline: uniform stage boxes, arrows in the gaps, cycle bar below
    ax = fig.add_subplot(gs[0, :])
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 2.5)
    ax.axis("off")
    stages = [
        ("Acquire\n8 s window", FS.C["blue"] + "30"),
        ("Band-pass\n+ SQI", "#e8e8e8"),
        ("KISR subspace\nrecon.", FS.C["red"] + "28"),
        ("Harmonic\ncomb HR", FS.C["green"] + "28"),
        ("BLE report\nevery 4 s", FS.C["purple"] + "28"),
        ("Sleep", "#d8d8d8"),
    ]
    n = len(stages)
    gap = 0.22
    bw = (10.0 - 0.2 - gap * (n - 1)) / n
    x = 0.1
    y0, bh = 1.15, 1.0
    for i, (t, c) in enumerate(stages):
        box(ax, x, y0, bw, bh, t, c, fs=5.6)
        if i < n - 1:
            ax.add_patch(FancyArrowPatch(
                (x + bw + 0.03, y0 + bh / 2), (x + bw + gap - 0.03, y0 + bh / 2),
                arrowstyle="-|>", mutation_scale=7, lw=0.8, color="#555555"))
        x += bw + gap
    bar_y = 0.55
    ax.annotate("", xy=(0.1, bar_y), xytext=(9.9, bar_y),
                arrowprops=dict(arrowstyle="<|-|>", lw=0.8, color="#666666"))
    ax.text(5.0, bar_y - 0.22,
            "one KISR update every 4 s  (wake \u2013 work \u2013 sleep)",
            ha="center", va="top", fontsize=6, color="#555555")
    ax.text(0.0, 1.02, "(d) On-node processing timeline", transform=ax.transAxes,
            fontsize=7.5, va="bottom", fontweight="bold")

    # ---- (b) power budget model (clearly a model)
    ax = fig.add_subplot(gs[1, 0])
    # engineering budget: datasheet-class figures for the block diagram in Fig.11
    labels = ["PPG AFE\n(64 Hz)", "IMU\n(64 Hz)", "MCU active\n(KISR)", "BLE TX",
              "Sleep\n(remainder)"]
    # average current contributions in mA (model assumptions, stated in caption)
    vals = [1.8, 0.4, 2.5, 1.2, 0.05]
    cols = [FS.C["red"], FS.C["blue"], FS.C["orange"], FS.C["purple"], FS.C["green"]]
    ax.bar(range(len(vals)), vals, color=cols, edgecolor="black", lw=0.5)
    ax.set_xticks(range(len(vals)))
    ax.set_xticklabels(labels, fontsize=5.6)
    ax.set_ylabel("Avg. current (mA)")
    ax.set_title("Modeled hourly energy breakdown", fontsize=7)
    for i, v in enumerate(vals):
        ax.text(i, v + 0.06, f"{v}", ha="center", fontsize=5.8)
    ax.set_ylim(0, max(vals) * 1.25)
    ax.text(-0.22, 1.10, "(e)", transform=ax.transAxes, fontsize=9, fontweight="bold")

    # ---- (c) battery life vs duty cycle
    ax = fig.add_subplot(gs[1, 1])
    # capacity 80 mAh; sleep current 0.05 mA; duty changes active share
    capacity = 80.0  # mAh
    active_ma = 1.8 + 0.4 + 2.5 + 1.2  # AFE + IMU + MCU + BLE when active
    sleep_ma = 0.05
    duty = np.linspace(0.05, 1.0, 40)
    current = duty * active_ma + (1 - duty) * sleep_ma
    hours = capacity / current
    ax.plot(duty * 100, hours, color=FS.C["blue"], lw=1.4)
    ax.axhline(24, color="gray", ls="--", lw=0.8)
    ax.text(8, 25, "24 h target", fontsize=6, color="gray")
    # mark the 4 s cadence used in the paper (~100% processing of 8 s windows/4 s)
    ax.axvline(100, color=FS.C["red"], ls=":", lw=1.0)
    ax.text(97, hours.max() * 0.85, "this work\n(100% duty)", fontsize=5.6,
            color=FS.C["red"], ha="right")
    ax.set_xlabel("Active duty cycle (%)")
    ax.set_ylabel("Modeled battery life (h)")
    ax.set_title("Budget model: 80 mAh cell", fontsize=7)
    ax.text(-0.22, 1.10, "(f)", transform=ax.transAxes, fontsize=9, fontweight="bold")

    out = os.path.join(FIGS, "fig12_power.png")
    fig.savefig(out, bbox_inches="tight", dpi=950)
    print("saved", out)


if __name__ == "__main__":
    main()
