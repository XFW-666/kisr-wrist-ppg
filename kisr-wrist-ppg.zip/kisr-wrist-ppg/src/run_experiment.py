"""Multi-record experiment over all complete wrist records.

Uses a subject-held-out-style protocol over the available records: for every
complete record, every method is evaluated on 8-s windows stepped by 4 s with the
harmonic-comb HR estimator (same estimator for all methods). Results are pooled
per record and overall, with per-record statistics kept for the paper figures.
"""
import os
import sys
import json
import time
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import ppglib as pl
import kisr as K

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WRIST = os.path.join(ROOT, "data", "wrist")
OUT = os.path.join(ROOT, "out")

WIN_S, STEP_S = 8.0, 4.0


def complete_records():
    sys.path.insert(0, os.path.join(ROOT, "src"))
    from fetch import expected_dat_size
    out = []
    for f in sorted(os.listdir(WRIST)):
        if f.endswith(".dat"):
            hea = os.path.join(WRIST, f[:-4] + ".hea")
            if os.path.exists(hea):
                exp = expected_dat_size(hea)
                if exp is not None and os.path.getsize(os.path.join(WRIST, f)) == exp:
                    out.append(f[:-4])
    return out


def activity_of(record):
    r = record.split("_", 1)[1] if "_" in record else record
    if "run" in r:
        return "run"
    if "walk" in r:
        return "walk"
    return "bike"


def intensity_of(record):
    return "high" if "high" in record else ("low" if "low" in record else "mod")


def run_record(rec_name, results):
    path = os.path.join(WRIST, rec_name)
    rec = pl.load_wrist(path)
    fs = rec["fs"]
    ppg, imu = rec["ppg"], np.concatenate([rec["acc"], rec["gyro"]], axis=1)
    rp = pl.ecg_rpeaks(rec["ecg"], fs)
    wl, sl = int(WIN_S * fs), int(STEP_S * fs)
    if len(ppg) < wl + sl:
        return
    starts = list(range(0, len(ppg) - wl, sl))
    prev = {m: None for m in K.METHODS}
    n_used = 0
    for s in starts:
        e = s + wl
        ref = pl.ref_hr(rp, fs, s / fs, e / fs)
        if not np.isfinite(ref) or ref < 40 or ref > 180:
            continue
        sqi = pl.ppg_sqi(ppg[s:e], fs)
        p, i = ppg[s:e], imu[s:e]
        n_used += 1
        row = {"t": round(s / fs, 1), "ref": round(float(ref), 2),
               "sqi": round(float(sqi), 3), "rec": rec_name,
               "act": activity_of(rec_name), "int": intensity_of(rec_name)}
        for name, fn in K.METHODS.items():
            try:
                y = fn(p, i, fs)
                hr, _ = pl.hr_harmonic(y, fs, prev=prev[name])
                if np.isfinite(hr):
                    prev[name] = hr
                row[name] = round(float(hr), 2) if np.isfinite(hr) else None
            except Exception:
                row[name] = None
        results.append(row)
    return n_used


def main():
    t0 = time.time()
    recs = complete_records()
    print(f"complete records: {recs}")
    results = []
    for r in recs:
        n = run_record(r, results)
        print(f"  {r}: {n} windows")
    os.makedirs(OUT, exist_ok=True)
    with open(os.path.join(OUT, "results_windows.json"), "w") as f:
        json.dump(results, f)

    methods = list(K.METHODS)
    print(f"\n{'method':22s} {'MAE':>6s} {'RMSE':>6s} {'P95':>6s} {'n':>5s}   (all)")
    summary = {}
    for m in methods:
        errs = [abs(w[m] - w["ref"]) for w in results if w.get(m) is not None]
        e = np.asarray(errs, dtype=float)
        e = e[np.isfinite(e)]
        summary[m] = {"mae": float(e.mean()) if e.size else None,
                      "rmse": float(np.sqrt((e ** 2).mean())) if e.size else None,
                      "p95": float(np.percentile(e, 95)) if e.size else None,
                      "n": int(e.size)}
        if e.size:
            print(f"{m:22s} {e.mean():6.2f} {np.sqrt((e**2).mean()):6.2f} {np.percentile(e,95):6.2f} {e.size:5d}")

    # by activity
    print("\nby activity:")
    acts = sorted({w["act"] for w in results})
    by_act = {}
    for a in acts:
        sub = [w for w in results if w["act"] == a]
        by_act[a] = {}
        for m in methods:
            errs = [abs(w[m] - w["ref"]) for w in sub if w.get(m) is not None]
            e = np.asarray(errs, dtype=float)
            e = e[np.isfinite(e)]
            by_act[a][m] = {"mae": float(e.mean()) if e.size else None, "n": int(e.size)}
        line = "  " + a.ljust(6)
        for m in methods:
            v = by_act[a][m]
            line += f"  {m.split(' ')[0]}={v['mae']:.1f}" if v["mae"] is not None else f"  {m.split(' ')[0]}=--"
        print(line)

    with open(os.path.join(OUT, "summary.json"), "w") as f:
        json.dump({"overall": summary, "by_activity": by_act,
                   "records": recs, "win_s": WIN_S, "step_s": STEP_S}, f, indent=1)
    print(f"\nelapsed {time.time()-t0:.1f}s  -> out/results_windows.json")


if __name__ == "__main__":
    main()
