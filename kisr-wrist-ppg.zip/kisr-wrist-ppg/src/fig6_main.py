"""Fig. 6 - Main results: HR estimation error across methods (multi-panel).

(a) Grouped bar chart of MAE per method, split by activity.
(b) Error distribution (box plots) per method over all windows.
(c) Empirical CDF of absolute HR error per method.
All values are computed from the pooled real windows in out/results_windows.json.
"""
import os
import sys
import json
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import figstyle as FS
import matplotlib.pyplot as plt

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FIGS = os.path.join(ROOT, "figures")
OUT = os.path.join(ROOT, "out")


def main():
    os.makedirs(FIGS, exist_ok=True)
    with open(os.path.join(OUT, "results_windows.json")) as f:
        results = json.load(f)
    methods = ["Raw (bandpass)", "LMS adaptive", "Spectral subtraction",
               "Wavelet+IMU", "ICA+IMU", "KISR (proposed)"]
    acts = sorted({w["act"] for w in results})

    errs = {m: {a: [] for a in acts} for m in methods}
    errs_all = {m: [] for m in methods}
    for w in results:
        for m in methods:
            if w.get(m) is not None:
                e = abs(w[m] - w["ref"])
                errs[m][w["act"]].append(e)
                errs_all[m].append(e)

    fig = plt.figure(figsize=(7.0, 2.03))
    gs = fig.add_gridspec(1, 3, wspace=0.5)

    # ---- (a) grouped bars: MAE per method per activity
    ax = fig.add_subplot(gs[0, 0])
    x = np.arange(len(methods))
    nb = len(acts)
    width = 0.8 / nb
    for ai, a in enumerate(acts):
        vals = [np.mean(errs[m][a]) if errs[m][a] else np.nan for m in methods]
        ax.bar(x + ai * width - 0.4 + width / 2, vals, width * 0.92,
               color=FS.ACT_COLORS[a], label=FS.ACT_LABEL[a], edgecolor="none")
    ax.set_xticks(x)
    ax.set_xticklabels(["Raw", "LMS", "SpecSub", "Wav", "ICA", "KISR"],
                       rotation=20, ha="right", fontsize=5.2)
    ax.set_ylabel("MAE (bpm)")
    ax.set_ylim(0, ax.get_ylim()[1] * 1.18)
    ax.text(-0.30, 1.12, "(a)", transform=ax.transAxes, fontsize=9, fontweight="bold")
    ax.legend(frameon=False, fontsize=5.5, loc="lower center",
              bbox_to_anchor=(0.55, 1.05), ncol=3, handlelength=1.1,
              handletextpad=0.35, columnspacing=0.8, borderaxespad=0.0)

    # ---- (b) box plots over all windows
    ax = fig.add_subplot(gs[0, 1])
    data = [np.asarray(errs_all[m]) for m in methods]
    bp = ax.boxplot(data, patch_artist=True, widths=0.55, showfliers=False,
                    medianprops=dict(color=FS.C["black"], lw=0.9))
    for patch, m in zip(bp["boxes"], methods):
        patch.set_facecolor(FS.METHOD_COLORS[m])
        patch.set_alpha(0.75)
        patch.set_edgecolor(FS.C["black"])
        patch.set_linewidth(0.6)
    ax.set_xticks(range(1, len(methods) + 1))
    ax.set_xticklabels(["Raw", "LMS", "SpecSub", "Wav", "ICA", "KISR"],
                       rotation=20, ha="right", fontsize=5.2)
    ax.set_ylabel("|HR error| (bpm)")
    ax.text(-0.32, 1.12, "(b)", transform=ax.transAxes, fontsize=9, fontweight="bold")

    # ---- (c) empirical CDF
    ax = fig.add_subplot(gs[0, 2])
    for m in methods:
        v = np.sort(np.asarray(errs_all[m]))
        cdf = np.arange(1, v.size + 1) / v.size
        ax.plot(v, cdf, color=FS.METHOD_COLORS[m], lw=1.1, label=m)
    ax.set_xlabel("|HR error| (bpm)")
    ax.set_ylabel("Cumulative fraction")
    ax.set_xlim(0, 60)
    ax.legend(frameon=False, fontsize=5.6, loc="upper left", ncol=1,
              handlelength=1.2, handletextpad=0.4, labelspacing=0.35,
              borderaxespad=0.3)
    ax.text(-0.38, 1.16, "(c)", transform=ax.transAxes, fontsize=9, fontweight="bold")

    out = os.path.join(FIGS, "fig6_main_results.png")
    fig.savefig(out, bbox_inches="tight")
    print("saved", out)


if __name__ == "__main__":
    main()
