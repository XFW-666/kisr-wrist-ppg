"""Shared SVG helpers: write SVG string, rasterize via svglib + rlPyCairo.

rlPyCairo prefers cairocffi (needs external libcairo) but works fine with
pycairo's API; we alias pycairo as cairocffi before rlPyCairo is imported so
the Windows wheel's bundled cairo bindings are used.
"""
import math
import os
import sys

# --- compatibility shim: pycairo provides `import cairo` with the same API ---
try:
    import cairocffi  # noqa: F401  (would need libcairo DLL)
except Exception:
    import cairo as _pycairo
    sys.modules["cairocffi"] = _pycairo

from svglib.svglib import svg2rlg
from reportlab.graphics import renderPM


def svg_to_png(svg_text, out_png, dpi=900):
    tmp = out_png + ".svg"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(svg_text)
    d = svg2rlg(tmp)
    if d is None:
        raise RuntimeError(f"svglib failed to parse {tmp}")
    renderPM.drawToFile(d, out_png, fmt="PNG", dpi=int(dpi))
    os.remove(tmp)
    return out_png


def font(size=12, weight="normal", fill="#1F1F1F", anchor="middle"):
    return (f'font-family="Helvetica, Arial, sans-serif" font-size="{size}" '
            f'font-weight="{weight}" fill="{fill}" text-anchor="{anchor}"')


def card(x, y, w, h, fill="#FFFFFF", stroke="#D0D5DD", rx=14, sw=1.2):
    return (f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}" '
            f'fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>')


def label(x, y, text, size=12, fill="#1F1F1F", anchor="middle", weight="normal"):
    return f'<text x="{x}" y="{y}" {font(size, weight, fill, anchor)}>{text}</text>'


def arrow(x1, y1, x2, y2, stroke="#667085", sw=1.6, head=None):
    head = head or stroke
    ang = math.atan2(y2 - y1, x2 - x1)
    ah = 7.0
    bx = x2 - ah * math.cos(ang - 0.45)
    by = y2 - ah * math.sin(ang - 0.45)
    cx = x2 - ah * math.cos(ang + 0.45)
    cy = y2 - ah * math.sin(ang + 0.45)
    return (f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{stroke}" stroke-width="{sw}"/>'
            f'<polygon points="{x2},{y2} {bx:.1f},{by:.1f} {cx:.1f},{cy:.1f}" fill="{head}"/>')


def chip(x, y, w, h, title, lines, fill="#EEF2FF", stroke="#6366F1", title_fill="#312E81"):
    body = [card(x, y, w, h, fill, stroke, 10, 1.4)]
    body.append(label(x + w / 2, y + 16, title, 11, title_fill, "middle", "bold"))
    for i, ln in enumerate(lines):
        body.append(label(x + w / 2, y + 30 + i * 11, ln, 8.2, "#475467"))
    return "\n".join(body)


def svg_open(w, h, bg="#F8FAFC"):
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" '
            f'viewBox="0 0 {w} {h}">'
            f'<rect x="0" y="0" width="{w}" height="{h}" fill="{bg}"/>')


def svg_close():
    return "</svg>"
