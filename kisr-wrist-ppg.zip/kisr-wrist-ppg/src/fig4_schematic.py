"""Fig. 4 - schematic-level diagram of the wrist node (matplotlib redraw).

Layout: two large blocks stacked on the left (MCU/BLE SoC, PPG AFE), nine
small blocks in a 3x3 grid on the right, note text at the bottom-left.
The machine-readable netlist remains hardware/wrist_node.kicad_sch
(kicad-cli render is kept as a hardware artifact, not the paper figure).

All label boxes are verified against each other and against symbol bodies
with the matplotlib renderer after drawing; any overlap raises an error.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import figstyle as FS
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Polygon

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FIGS = os.path.join(ROOT, "figures")

BODY = "#fff9c2"      # pale yellow symbol body (KiCad-like)
EDGE = "#8b2c2c"      # dark red outline / pins / net flags
REFC = "#004d80"      # navy bold reference designators
VALC = "#0a6e4e"      # green part values
NAMEC = "#1f4e79"     # pin names
NOTEC = "#555555"     # bottom-left note text

# name, ref, value, w, h, left-pins, right-pins
SYMBOLS = {
    "MCU_BLE": ("U9", "nRF52840", 30, 36,
                ["I2C_SCL", "I2C_SDA", "SPI_SCK", "SPI_MOSI",
                 "SPI_CS", "SWDIO", "SWCLK", "GND"],
                ["SPI_MISO", "ANT", "VDD"]),
    "PPG_AFE": ("U1", "AFE4400", 26, 34,
                ["LED_K", "LED_A", "PD_A", "PD_K", "SCLK", "SDI", "CS", "GND"],
                ["SDO", "VDD"]),
    "ACC_WIDE": ("U2", "ICM-42688-P", 18, 16,
                 ["SDA", "SCL", "GND"], ["INT1", "VDD"]),
    "ACC_LN": ("U3", "LSM6DSV", 18, 16,
               ["SDA", "SCL", "GND"], ["INT2", "VDD"]),
    "GYRO": ("U4", "LSM6DSV-G", 18, 16,
             ["SDA", "SCL", "GND"], ["INT", "VDD"]),
    "MAG": ("U5", "LIS3MDL", 18, 16,
            ["SDA", "SCL", "GND"], ["DRDY", "VDD"]),
    "ALS": ("U7", "MAX86176", 16, 16,
            ["SDA", "SCL", "GND"], ["INT", "VDD"]),
    "TEMP": ("U6", "TMP117", 16, 16,
             ["SDA", "SCL", "GND"], ["ALERT", "VDD"]),
    "BARO": ("U8", "LPS22HH", 16, 14,
             ["SDA", "SCL", "GND"], ["VDD"]),
    "ECG_HD": ("J1", "ECG_PADS", 16, 14,
               ["RA", "LA", "RL"], []),
    "LDO": ("U10", "TPS7A02", 16, 14,
            ["VIN", "GND", "EN"], ["VOUT"]),
}

# which pins carry a global net flag, and the net name
NET_FLAGS = {"SDA": "I2C_SDA", "SCL": "I2C_SCL",
             "I2C_SDA": "I2C_SDA", "I2C_SCL": "I2C_SCL",
             "SWDIO": "SWDIO", "SWCLK": "SWCLK",
             "SCLK": "SPI_SCK", "SDI": "SPI_MOSI",
             "SDO": "SPI_MISO", "CS": "SPI_CS",
             "SPI_SCK": "SPI_SCK", "SPI_MOSI": "SPI_MOSI",
             "SPI_MISO": "SPI_MISO", "SPI_CS": "SPI_CS",
             "ANT": "ANT", "RA": "RA", "LA": "LA", "RL": "RL"}

PLACEMENTS = [
    # two large blocks stacked on the left
    ("MCU_BLE", 30, 66),
    ("PPG_AFE", 30, 19),
    # nine small blocks, 3 x 3 grid on the right
    ("ACC_WIDE", 96, 58),
    ("ACC_LN", 96, 30),
    ("GYRO", 96, 2),
    ("MAG", 142, 58),
    ("ALS", 142, 30),
    ("TEMP", 142, 2),
    ("BARO", 188, 58),
    ("ECG_HD", 188, 30),
    ("LDO", 188, 2),
]

NOTE_LINES = [
    "KISR wrist sensing node - multi-sensor front end",
    "Dual-wavelength PPG AFE + dual-range accel + gyro",
    "+ mag + temp + ALS + baro + ECG",
    "Import to JLC EasyEDA Pro: File > Import > KiCad",
]

X0, X1, Y0, Y1 = 0, 208, -15, 90
PIN_LEN = 5.0


def text_w(s, fs_pt):
    """Conservative width in data units for proportional text."""
    return len(s) * fs_pt / 72.0 * 0.60 / (7.0 / (X1 - X0))


def flag(ax, px, py, label, side):
    """KiCad-style net flag hanging off a pin tip."""
    fs = 4.2
    w = text_w(label, fs) + 2.2
    h = 3.0
    tip = 1.8
    s = -1 if side == "L" else 1
    tip_x = px
    body_x = tip_x + s * tip
    far_x = body_x + s * w
    poly = Polygon([(tip_x, py), (body_x, py + h / 2), (far_x, py + h / 2),
                    (far_x, py - h / 2), (body_x, py - h / 2)],
                   closed=True, fc=BODY, ec=EDGE, lw=0.7, zorder=3)
    ax.add_patch(poly)
    cx = (body_x + far_x) / 2
    ax.text(cx, py, label, ha="center", va="center", fontsize=fs,
            color=EDGE, zorder=4)


def draw_symbol(ax, key, cx, cy, pin_texts):
    ref, val, w, h, lpins, rpins = SYMBOLS[key]
    hw, hh = w / 2, h / 2
    ax.add_patch(Rectangle((cx - hw, cy - hh), w, h,
                           fc=BODY, ec=EDGE, lw=1.0, zorder=2))
    ax.text(cx, cy + hh + 2.4, ref, ha="center", va="bottom",
            fontsize=6.6, fontweight="bold", color=REFC, zorder=4)
    ax.text(cx, cy - hh - 2.4, val, ha="center", va="top",
            fontsize=5.6, color=VALC, zorder=4)
    for pins, side in ((lpins, "L"), (rpins, "R")):
        n = len(pins)
        if n == 0:
            continue
        pitch = h / (n + 1)
        for i, name in enumerate(pins):
            py = cy + hh - (i + 1) * pitch
            if side == "L":
                tip_x = cx - hw - PIN_LEN
                ax.plot([tip_x, cx - hw], [py, py], color=EDGE, lw=0.9,
                        zorder=2, solid_capstyle="butt")
                # pin name inside the body (KiCad convention)
                pin_texts.add(ax.text(cx - hw + 1.0, py, name, ha="left",
                                      va="center", fontsize=4.6,
                                      color=NAMEC, zorder=3))
            else:
                tip_x = cx + hw + PIN_LEN
                ax.plot([cx + hw, tip_x], [py, py], color=EDGE, lw=0.9,
                        zorder=2, solid_capstyle="butt")
                pin_texts.add(ax.text(cx + hw - 1.0, py, name, ha="right",
                                      va="center", fontsize=4.6,
                                      color=NAMEC, zorder=3))
            if name in NET_FLAGS:
                flag(ax, tip_x, py, NET_FLAGS[name], side)


def bbox_overlap(a, b):
    return not (a[1] <= b[0] or b[1] <= a[0] or a[3] <= b[2] or b[3] <= a[2])


def verify_no_overlap(fig, ax, bodies, pin_texts):
    """Measure every text with the real renderer; flag any collisions.

    Pin names are intentionally drawn just inside the symbol body (KiCad
    convention), so they are excluded from text-body checks but still
    checked against other texts.
    """
    fig.canvas.draw()
    r = fig.canvas.get_renderer()
    inv = ax.transData.inverted()
    boxes = []
    for t in ax.texts:
        if not t.get_text().strip():
            continue
        bb = t.get_window_extent(renderer=r)
        (x0, y0), (x1, y1) = inv.transform([(bb.x0, bb.y0), (bb.x1, bb.y1)])
        boxes.append((t.get_text(), (x0, x1, y0, y1), t in pin_texts))
    problems = []
    for i in range(len(boxes)):
        for j in range(i + 1, len(boxes)):
            if bbox_overlap(boxes[i][1], boxes[j][1]):
                problems.append(("text-text", boxes[i][0], boxes[j][0]))
        if boxes[i][2]:
            continue
        for bi, (bx0, bx1, by0, by1) in enumerate(bodies):
            if bbox_overlap(boxes[i][1], (bx0, bx1, by0, by1)):
                problems.append(("text-body", boxes[i][0], f"body#{bi}"))
    return problems


def main():
    fig = plt.figure(figsize=(7.0, 7.0 * (Y1 - Y0) / (X1 - X0)))
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(X0, X1)
    ax.set_ylim(Y0, Y1)
    ax.axis("off")

    bodies = []
    pin_texts = set()
    for key, cx, cy in PLACEMENTS:
        draw_symbol(ax, key, cx, cy, pin_texts)
        _, _, w, h, _, _ = SYMBOLS[key]
        bodies.append((cx - w / 2, cx + w / 2, cy - h / 2, cy + h / 2))

    for i, line in enumerate(NOTE_LINES):
        ax.text(3, -5.0 - i * 2.3, line, ha="left", va="top",
                fontsize=5.2, color=NOTEC, zorder=4)

    problems = verify_no_overlap(fig, ax, bodies, pin_texts)
    if problems:
        for p in problems:
            print("OVERLAP:", p)
        raise SystemExit(f"{len(problems)} label collisions detected")

    out = os.path.join(FIGS, "fig11b_kicad_schematic.png")
    fig.savefig(out, dpi=950)
    print("saved", out)


if __name__ == "__main__":
    main()
