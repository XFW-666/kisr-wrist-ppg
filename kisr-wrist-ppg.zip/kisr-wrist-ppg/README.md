# KISR wrist PPG: analysis code, derived outputs, and hardware files

This repository accompanies the study *Motion-Robust Wrist Photoplethysmography
via Kinematic-Informed Subspace Reconstruction with Sensor-Centric Accuracy,
Interference, and Front-End Sizing Evidence*. Every number, table, and figure in
the paper can be regenerated from the material stored here.

## Layout

| path | contents |
| --- | --- |
| `src/` | analysis code (experiments, ablations, figures, schematic netlist generator) |
| `out/` | derived outputs (window-level errors, summary statistics, ablations, reference list) |
| `figures/` | the nine composites embedded in the paper (`g1` to `g9`) plus the schematic concept artwork in `figures/fix/` |
| `hardware/` | wrist-node schematic netlist, bill of materials, sensor suite description |

## Raw data

The raw recordings are public and are **not** redistributed here. Fetch them
from the official PhysioNet servers into `data/` with:

```
python src/fetch.py
```

The script pulls the wrist PPG/IMU/ECG recordings used in the paper plus the
MIT-BIH and BIDMC reference sets into `data/wrist/`, `data/mitdb/` and
`data/bidmc/`.

## Reproducing the results

Python 3.10 or newer, with the packages listed in `requirements.txt`.

```
python src/fetch.py               # raw signals -> data/
python src/run_experiment.py      # -> out/results_windows.json, out/summary.json
python src/run_ablation.py        # -> out/ablation.json
python src/run_nature_supp.py     # -> out/stats.json, sensor_ablation.json, mechanism.json
python src/fig7_ba.py             # -> out/fig7_stats.json (agreement statistics)
python src/fig2_signal.py         # signal characterisation panels
python src/fig5_subspace.py       # subspace walk-through panels
python src/fig6_main.py           # main comparison panels
python src/fig8_per_record.py     # per-record panels
python src/fig9_ablation.py       # component ablation panels
python src/fig10_design_space.py  # sampling-rate and ADC design space
python src/fig12_power.py         # power model panels
python src/fig4_schematic.py      # wrist-node schematic figure
python src/fig_sensor_concepts.py # sensor waveform panel
python src/merge_figures.py       # stacks the panels into figures/g1..g9
```

`figures/fix/` holds the schematic concept artwork that `merge_figures.py`
stacks under the panel rows. The remaining panel PNGs in `figures/` are
rebuilt by the figure scripts above; `g*.png` are also checked in so the
archived composites can be viewed without rerunning anything.

`out/results_windows.json` holds one entry per analysis window (reference HR
from chest ECG plus each method's estimate), which is what the tables and the
error statistics are computed from.

## Hardware

`hardware/wrist_node.kicad_sch` is the schematic-level netlist of the wrist
node: dual-wavelength PPG AFE, wide-range and low-noise accelerometers,
gyroscope, magnetometer, temperature and ambient-light sensors, barometer,
MCU/BLE SoC, LDO, and the ECG pad header on shared I2C/SPI buses. It opens in
KiCad and imports into EasyEDA Pro through File > Import > KiCad. The matching
bill of materials is `hardware/wrist_node_BOM.csv`.

## License

The code is released under the MIT License (see `LICENSE`). The derived
outputs and figures are released under CC BY 4.0.
